# ArtInHCI44493 essential submission materials

This package accompanies **Prototype-Guided Reliability for Streaming CLIP Adaptation**. It contains the final manuscript, four color vector figures, core implementation and protocols, and selected result summaries. The reports retain the published positive and negative results.

## Where to start

- `paper/`: final editable Word manuscript, matching 11-page PDF, and the separate proofreading contact.
- `figures/`: the four final vector PDF figures; duplicate PNG/SVG copies are omitted.
- `code/`: 14 Python files, three study protocols, and the original dependency list. The primary implementation, fixed gate, source-validated policy, QuickDraw holdout and analysis routines are included with their local dependencies.
- `reports/`: summaries supporting Tables 1–8 and Figures 2–3. `runs.csv` is one compact table of per-run scalar results, not thousands of prediction files.
- `online_e2e/`: only selected protocol, calibration, summary and historical audit records.
- `quickdraw_data*/DATA_CARD.json`: public-data selection recipes and original subset hashes; drawing records can be downloaded by the included runners.

The exact paths cited in the paper remain `reports/paired_tests.csv` and `reports/terra_scale_ablation.json`. The first contains all 14 primary Holm comparisons, including the seven confidence-weighted comparisons omitted from the paper's displayed subset. The second contains the 480-run factorial contrasts. `reports/source_validated_gate_20260929.json` records the eight source-selected policies and the Terra prototype/zero-shot difference. The independent QuickDraw holdout summary is under `online_e2e/gate_holdout_independent_20260929/`.

## Scope of the compact release

Full prediction arrays, batch logs, raw per-run folders, dataset images, feature tensors, model weights, historical manuscript versions, deployment helpers and internal editorial checks are excluded. Historical audit reports document checks performed on the complete retained experiment archive; the compact package alone cannot repeat those full-array or input-tensor integrity checks. The independent QuickDraw holdout originally saved order summaries only, not per-sample predictions. No new model experiment was run to assemble this package.

The external-method results are retained in `reports/external.json`; their separate third-party repositories/checkpoints and deployment wrappers are not bundled. Some protocol/audit records refer to raw files in the full experiment archive. Those references describe historical evidence, not additional files claimed to be present here.

## Verify the delivered files

After extracting the ZIP, run from its root:

```text
python code/verify_supplement.py --root .
```

`SHA256_MANIFEST.json` covers every delivered file except itself. All retained result files are unchanged. The only cleanup to existing code is removal of the unused `source_threshold` import from `gated_cached_validation.py`; its local `source_threshold_generic` computation is unchanged. This avoids bundling an unnecessary chain of raw-stream helpers.

## Run new experiments

Use a clean environment with CUDA-compatible PyTorch/torchvision. Install the remaining dependencies:

```text
python -m pip install -r code/legacy/requirements.txt requests matplotlib
```

Obtain PACS, OfficeHome and TerraIncognita from their original providers or [DomainBed](https://github.com/facebookresearch/DomainBed), following the class/domain order in `code/legacy/datasets.py` and `domainbed_dataset.py`. OpenCLIP downloads model weights separately. The B/16 LAION tag is `laion2b_s34b_b88k`; the OpenAI comparison explicitly uses QuickGELU. Read `code/PROTOCOL.md` before changing settings.

Replace `DATA_ROOT` and `WORK` with your data directory and a new output directory. The full primary matrix generates caches and raw run files:

```text
python code/run_revision.py --legacy-code code/legacy --data-root DATA_ROOT --out WORK/core
```

For one setting, append `--only OfficeHome ViT-B-16`, `--only TerraIncognita ViT-B-16`, or `--only PACS ViT-B-16`. A subset is insufficient for full-matrix inference. After the corresponding B/16 caches exist:

```text
python -c "import sys; from pathlib import Path; sys.path.insert(0,'code'); import gated_cached_validation as g; g.run_setting(Path('WORK'),Path('WORK/online_e2e/gated_office_20260929'),'OfficeHome','ViT-B-16')"
python code/gated_terra_validation.py --root WORK --out WORK/online_e2e/gated_terra_20260929
python code/source_validated_gate.py --features-root WORK/core/features --adapter-script code/run_revision.py --out WORK/online_e2e/source_validated_20260929
```

For the QuickDraw pilot and disjoint records 501–1000, first generate the PACS B/16 cache, then run:

```text
python code/quickdraw_application.py --root WORK --legacy-code code/legacy
python -c "import os,runpy; os.environ['PGR_FEATURES_ROOT']='WORK/core/features'; os.environ['PGR_HOLDOUT_OUT']='WORK/quickdraw_holdout'; runpy.run_path('code/independent_gate_holdout.py',run_name='__main__')"
```

The runners download the public drawing prefixes when absent. `PGR_B16_CHECKPOINT` can specify a matching local checkpoint. Retained data cards describe the original inputs; compare newly downloaded records with them before treating a rerun as input-equivalent. Dataset source: [Google Quick, Draw!](https://github.com/googlecreativelab/quickdraw-dataset), CC BY 4.0.

## Analyze newly generated outputs

After the complete primary raw outputs exist:

```text
python code/analyze_revision.py --root WORK
```

This needs the JSON/NPZ run tree; included summary reports do not replace those inputs. Application/external analyses additionally require their own generated outputs.

For the factorial, both Terra B/16 and L/14 caches are required:

```text
python code/run_terra_scale_ablation.py --core-root WORK/core --out WORK/terra_scale_ablation
python code/analyze_terra_scale_ablation.py --input WORK/terra_scale_ablation --out-json WORK/terra_scale_ablation.json --out-csv WORK/terra_scale_ablation.csv
```

The factorial analysis requires all 480 generated records and `completion.json`. `analyze_source_validated_gate.py` is retained as the source-policy audit implementation; its full audit additionally requires the raw source-CV/target/comparator trees, matching original tensors and adapter at the paths described by its CLI and protocol. These are excluded from the compact archive. Newly generated runs are new execution evidence, not recovered original prediction arrays.
