# Actual QuickDraw gate decision records: order seed 200

`QuickDraw__sketch__b64__s200.jsonl` is a byte-for-byte copy of one saved experimental batch log. It contains 47 JSON objects (46 batches of 64 drawings and a final batch of 56), covering 3,000 drawings exactly once. No measurements or fields were added, regenerated, or edited for this example.

## Scope and outcome

This is the original QuickDraw prefix pilot: the first 500 nonempty public simplified records for each of six categories, described in `quickdraw_data/DATA_CARD.json` at the zip root. The stream uses order seed 200 and the LAION OpenCLIP ViT-B/16 checkpoint. It is **not** the later independent 20-order holdout, which uses disjoint records 501–1000 and retains order summaries only.

The source-correct 25th-percentile threshold is 0.6221603155136108. It was calibrated using 4,757 source-correct observations from PACS art painting, cartoon, and photo. The same value appears in `online_e2e/gated_final/calibration.json` at the zip root. All 47 batch medians (0.347334–0.544144) are below this threshold, so all 47 batches take the zero-shot fallback. `online_e2e/gated_final/audit.json` corroborates 0 accepted batches across the five original batch-64 orders (235 batches), and 73.20% gate accuracy for seed 200. Accuracy is reported by the original run/audit, not recomputed from this decision log.

This small example makes the saved decision record inspectable. It demonstrates rejection/fallback decisions only; it does not demonstrate acceptance of beneficial updates or enable a full prediction-array/cache replay.

## Recorded fields and decision mapping

| JSON field | Meaning |
| --- | --- |
| `batch`, `stream_start`, `n` | Zero-based batch index, stream offset, and batch size. |
| `sample_indices` | Indices into the original 3,000-drawing pilot; their concatenation is the saved stream order. |
| `batch_median_score` | Recorded batch median reliability, corresponding to r_med. |
| `threshold` | The fixed source-calibrated threshold, corresponding to tau. |
| `gate_enabled` | Recorded decision: true iff `batch_median_score >= threshold`. |
| `log_scale_before`, `log_scale_after` | Recorded carried logit-scale state immediately before and after the batch. They are equal (4.605199813842773) for every batch here. |
| `prototype_change_l2` | The original logger writes 0.0 for this frozen-prototype configuration; this is a configuration constant, not a separately recomputed per-batch distance. |
| `predictions_committed_before_next_batch` | The original logger's commit-order flag, true on every row. |

The original schema does **not** contain fields literally named `path` or `state_action`. Their interpretation follows the implemented gate branch: `gate_enabled=false` selects zero-shot logits and skips adaptation, retaining the adapter state; `gate_enabled=true` calls the PGR frozen-prototype adaptation path. For this example, every decision is therefore **zero-shot / skip adaptation and retain state**, supported by the recorded false decisions and unchanged log-scale values. This mapping is explained here instead of adding derived fields to the authentic log. The shared adaptation implementation is in `code/run_revision.py`; its `pr_frozen` configuration fixes source prototypes. The original event generator was `code/gated_online_validation.py` in the full results archive and is not bundled in this compact zip.

## Provenance and checksums

- Original archive: `ArtInHCI44493_full_results_20260929.zip` (retained local full-results backup).
- Original archive SHA-256: `7c7e871616acc3812155a47b0b55e649646cf21c73664e2e45e96a77aecbdbcf`.
- Original member: `online_e2e/gated_final/batches/QuickDraw__sketch__b64__s200.jsonl`.
- Log size: 31,770 bytes.
- Log SHA-256: `f67dff2fc6fdc4856463d7b5422e5e2f6d1ea01d00ba939a9ad13cd7096a02f8`.
- The original run summary `online_e2e/gated_final/runs/QuickDraw__sketch__b64__s200.json` records exactly this value as `events_sha256`.
- Concatenated sample-index order SHA-256 (little-endian int64): `338ad82e91ae4a2cc4d01b4d1d4099f8a41bf35b26013800e2724345720ec917`; matches that run summary's `order_sha256`.
- Original event-generator SHA-256: `f3bd0ba4e251b421966b069d9f2a2bd1a512ad4227bfa6f905feccc8a73f51e8`; also recorded in `online_e2e/gated_final/audit.json` as `script_sha256`.

The full results backup and individual run summary are not included in the compact zip. The log checksum is independently covered by its root `SHA256_MANIFEST.json`. To inspect this example with Python's standard library from the zip root:

```python
from pathlib import Path
import hashlib
import json

p = Path("examples/quickdraw_gate_order200/QuickDraw__sketch__b64__s200.jsonl")
b = p.read_bytes()
assert hashlib.sha256(b).hexdigest() == "f67dff2fc6fdc4856463d7b5422e5e2f6d1ea01d00ba939a9ad13cd7096a02f8"
rows = [json.loads(line) for line in b.decode().splitlines()]
assert len(rows) == 47
assert sum(r["n"] for r in rows) == 3000
assert all(r["gate_enabled"] == (r["batch_median_score"] >= r["threshold"]) for r in rows)
assert all(not r["gate_enabled"] for r in rows)
assert all(r["log_scale_before"] == r["log_scale_after"] for r in rows)
print("47 authentic fallback decisions; log checksum verified.")
```
