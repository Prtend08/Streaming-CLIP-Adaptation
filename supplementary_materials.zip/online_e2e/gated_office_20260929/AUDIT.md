# OfficeHome gate audit (2026-09-29)

Original audit date: 2026-09-29. The initial audit below predates the later
provenance recovery. Updated on 2026-09-29 after local feature-file verification;
the cloud metadata was captured at 02:27:26 UTC (10:27:26 Asia/Shanghai), **after
execution**. Later collection is not relabeled as a contemporaneous run log.

## Scope and inputs

This audit checks the cached OfficeHome/B-16 gate pilot under
`revision_20260901/synced/online_e2e/gated_office_20260929/` against the existing
OfficeHome/B-16 core replay under
`revision_20260901/synced/core/`, and recomputes the summary in
`revision_20260901/synced/reports/office_gate_20260929.json`.

The gate contains 40 completed streams: four domains (`Art`, `Clipart`,
`Product`, `Real_World`) × ten orders (seeds 100--109), batch size 64. The
completion marker reports `run_count=40`, `expected=40`, and `complete=true`.

## Checks that pass

1. **Run/NPZ integrity.** All 40 JSON records are complete. Every run's
   `accuracy` and `correct` value recompute exactly from its NPZ
   (`prediction`, `labels`, `order`) arrays. All 40 prediction SHA-256 values
   and order SHA-256 values match the files. NPZ gate flags and batch scores
   match the JSON batch records; every gate flag agrees with
   `batch_median_score >= threshold`.

2. **Order and sample alignment.** For every domain and seed, the gate NPZ
   `order` and `labels` arrays are byte-for-byte equal to the matching core
   `__pr_frozen__{seed}.npz` arrays. This rules out a changed sample ordering
   or label mapping in the cached pilot.

3. **Locked source-only calibration.** Each target domain is excluded from
   its calibration source list. The four calibrations use the 25th percentile
   of scores from correctly classified held-out source examples, with
   `target_labels_used=false` in every calibration file and
   `target_labels_used_by_gate=false` in the protocol. Runtime score code
   receives the target features and zero-shot probabilities only; target
   labels are used for final scoring after the stream.

4. **Fallback state behavior.** There are 2,460 recorded batches, of which
   2,354 are enabled and 106 are disabled. All disabled batch records preserve
   the prior logged log-scale value (no scale jump); the cached source code
   does not call `predict` on a disabled batch. This is consistent with the
   stated zero-shot fallback semantics.

5. **Recomputed accuracy.** The report values reproduce from the 40 run files:

   | Domain | Gate accuracy (mean ± sample SD) | Enabled batches | Zero-shot | Gate − ZS |
   |---|---:|---:|---:|---:|
   | Art | 84.8702 ± 0.1931 | 288/380 | 85.0021 | −0.1319 |
   | Clipart | 76.6987 ± 0.2305 | 676/690 | 76.8156 | −0.1168 |
   | Product | 92.6245 ± 0.1414 | 700/700 | 92.9489 | −0.3244 |
   | Real_World | 92.6303 ± 0.1370 | 690/690 | 92.6555 | −0.0252 |
   | OfficeHome macro | 86.7059 | 2354/2460 | 86.8555 | −0.1496 |

   The macro row is the equal-domain mean of the four domain means. From raw
   predictions it is 86.70591631%; the original report's 86.705925% differed
   only because it averaged already-rounded domain numbers. The report is now
   recomputed from raw predictions. At the order level, using integer correct
   counts, the gate exceeds zero-shot in 9/40 orders (Art 3/10, Clipart 2/10,
   Product 0/10, Real_World 4/10), loses in 28/40, and ties in 3/40.
   A preliminary strict comparison to float32 baseline percentages incorrectly
   classified the three ties, so all sign counts now use integer counts.
   This is a negative stress check with some positive individual
   orders, not evidence of a net OfficeHome improvement.

## Protocol/provenance status and remaining limitations

- **Determinism settings are not pinned in the gate script.** The main core
  replay records `torch 2.1.2+cu121` and explicitly sets
  `torch.backends.cuda.matmul.allow_tf32=False`,
  `torch.backends.cudnn.allow_tf32=False`, and `torch.backends.cudnn.benchmark=False`.
  The cached gate scripts do not set these flags. A later environment record
  is now present in `provenance/post_run_provenance.json`; it records Python
  3.10.8, Torch 2.1.2+cu121, OpenCLIP 3.3.0, CUDA 12.1, and RTX 3090. Its
  capture-process defaults are matmul TF32 false, cuDNN TF32 true, and cuDNN
  benchmark false. These are **post-run process defaults**, not evidence of
  the exact original execution-process flags. The lack of contemporaneous
  flag logging remains a limitation; no experiment was rerun for this update.

- **Provenance was recovered after execution.** The gate directory now has
  `provenance/post_run_provenance.json` and four input manifests in addition
  to the protocol, calibrations, and 40 raw run pairs. The post-run record
  hashes the current source scripts, local checkpoint files, all four image
  feature tensors, and text weights. The two recorded checkpoint paths share
  SHA-256 `3f25d29d3cc74e1d25d47e0593b4dd0864ced1e9b4d8e486a247ca4502f227f1`.
  A later hash captures file content at collection time, not an independent
  attestation that an unchanged file was loaded during the earlier run.

- **Recovered tensors are independently checked.** All ten restored
  OfficeHome/TerraIncognita `.pt` files pass local SHA-256 and byte-size checks
  against their respective post-run provenance records (83,180,874 bytes
  total), recorded in `revision_20260929/restored_features_verification.json`.
  All four OfficeHome image tensor hashes also exactly equal their historical
  manifest feature hashes. In contrast, all four regenerated Terra image
  tensor hashes differ from their historical manifest feature hashes. An old
  manifest alone cannot prove a new tensor is the same serialized file: that
  conclusion requires independently hashing the actual recovered file. The
  OfficeHome equality is supported by that independent comparison; Terra
  must be described as a reconstructed cache, with output-level agreement
  documented in the Terra audit. Historical text-weight identity is not
  established by these manifests, which contain no text-weight reference hash.

- **State-action logging is thinner than the PACS online gate.** OfficeHome
  batch records log `scale` only after each batch; they do not record
  `scale_before`, `scale_after`, or an explicit state action. The unchanged
  disabled scale sequence plus source code establish the fallback behavior,
  but the raw OfficeHome records alone cannot independently verify a before/after
  state transition. Do not describe these OfficeHome records as a complete
  decision-record schema unless the fields are added or the wording is scoped
  to the PACS online logs.

- **Calibration-bank shift.** For each target, calibration holds out one of
  the three permitted source domains and builds its source prototype from the
  other two; deployment computes the target score with the prototype built from
  all three permitted source domains. This is the intended leave-one-source
  calibration heuristic, but the score distributions are not identical. The
  report should retain the existing caveat that transfer of the threshold is
  not guaranteed.

- **Scope.** This is a cached-feature replay on the same OfficeHome benchmark,
  not an independent dataset or user study. The gate remains a post-revision
  guardrail check. TerraIncognita has subsequently completed its own 40-stream
  gate replay in `online_e2e/gated_terra_20260929`; it is separately audited.
  Its gate macro is 18.3379%, compared with 17.3445% always-on frozen PGR and
  23.5444% zero-shot, accepting 3,405/3,890 batches. Thus the additional result
  also exposes a limitation of the gate rather than a no-harm guarantee.

## Recommended manuscript wording

Use the OfficeHome result as a cross-dataset stress check: `2,354/2,460`
batches were accepted; macro accuracy was `86.71%` versus `86.86%` zero-shot
(`−0.15` points). State that nine individual orders exceed zero-shot but the
aggregate is negative. Do not call it positive gate efficacy. Keep the PACS
pilot as the positive evidence that some accepted updates can help, and retain
an explicit limitation about source-bank calibration transfer. Include the
completed Terra stress check as a separate result; it improves on always-on
adaptation but remains below zero-shot.

## Hashes used for this audit

- Initial local `gated_cached_validation.py` audit copy (5,270 bytes):
  `c7647ff17ac45849a553b992aaab2f907cc9d0dcd416b9df0c430f2ef4146f1e`.
- Post-run cloud `gated_cached_validation.py` (5,217 bytes):
  `070918ea55012fa7f6df3c0d12069bddbbc23bd1d8f6f27d76ea5f944215f0e6`.
  Removing exactly the unused import line
  `from gated_online_validation import source_threshold` and its newline
  from the initial local copy reproduces both this byte size and SHA-256.
  This verifies the content difference between those two recorded versions;
  it does not establish the historical modification time.
- Post-run cloud `gated_office_validation.py` (5,029 bytes):
  `f9947781a94f3441fadc1792d0f0b9818de0e1f23824e86468cfec4b4e14a400`.
  Starting from the 5,217-byte cached script, restricting `SETTINGS` to
  OfficeHome/ViT-B-16 and changing the completion/assertion count from 400
  to 40 reproduces this exact size and SHA-256. The audited calibration and
  adaptation functions are otherwise unchanged in that exact reconstruction.
- Core `run_revision.py`: `92235ec71835fc25d86f8f2ea113d1a183409f88b4b26eec91bda877ad18c424`
- Core environment record: `revision_20260901/synced/core/environment.json`
- OfficeHome/B-16 feature manifest SHA-256 values are preserved in
  `revision_20260901/synced/core/features/OfficeHome/ViT-B-16/*.manifest.json`.
