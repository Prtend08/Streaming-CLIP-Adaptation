# Post-hoc source-validated gate audit

Audit UTC: 2026-09-29T03:00:22.138688+00:00. Status: **PASS**.

This is a new post-hoc policy developed after the earlier benchmark outcomes were known. The earlier gate and always-on results remain unchanged. Source-only selection does not make these reused benchmark families independent confirmation.

Inventory: 80 target streams, 72 source-validation streams, 8 policy selections, and 80 target label-free archives.

All reported SDs are sample SDs across ten matched orders. Macro SD uses the ten equal-domain macro accuracies, not forty pooled domain/order rows. These orders reuse the same examples.

## OfficeHome

| Domain | Policy ± SD | ZS | Source prototype | Original gate | Always-on | Fallback; gate allowed | Accepted |
|---|---:|---:|---:|---:|---:|---|---:|
| Art | 85.002060 ± 0.000000 | 85.002060 | 80.098888 | 84.870210 | 84.812526 | zeroshot; False | 0/380 |
| Clipart | 76.815578 ± 0.000000 | 76.815578 | 74.707904 | 76.698740 | 76.710195 | zeroshot; False | 0/690 |
| Product | 92.948862 ± 0.000000 | 92.948862 | 89.817526 | 92.624465 | 92.624465 | zeroshot; False | 0/700 |
| Real_World | 92.655497 ± 0.000000 | 92.655497 | 90.452146 | 92.630250 | 92.630250 | zeroshot; False | 0/690 |
| Macro | 86.855499 ± 0.000000 | 86.855499 | 83.769116 | 86.705916 | 86.694359 | per domain | 0/2460 |

Macro paired changes (percentage points): vs zeroshot: +0.00000000 ± 0.00000000; vs original_gate: +0.14958316 ± 0.10957351; vs always_on_frozen: +0.16114056 ± 0.10769865.

## TerraIncognita

| Domain | Policy ± SD | ZS | Source prototype | Original gate | Always-on | Fallback; gate allowed | Accepted |
|---|---:|---:|---:|---:|---:|---|---:|
| location_100 | 18.097971 ± 0.000000 | 18.097971 | 35.704038 | 6.177495 | 6.177495 | zeroshot; False | 0/770 |
| location_38 | 17.927716 ± 0.000000 | 17.927716 | 35.886147 | 15.663971 | 15.618921 | zeroshot; False | 0/1530 |
| location_43 | 33.208955 ± 0.000000 | 33.208955 | 26.965174 | 30.820896 | 30.820896 | zeroshot; False | 0/630 |
| location_46 | 24.942829 ± 0.000000 | 24.942829 | 26.951976 | 20.689317 | 16.760862 | zeroshot; False | 0/960 |
| Macro | 23.544368 ± 0.000000 | 23.544368 | 31.376834 | 18.337920 | 17.344544 | per domain | 0/3890 |

Macro paired changes (percentage points): vs zeroshot: +0.00000000 ± 0.00000000; vs original_gate: +5.20644810 ± 0.15492188; vs always_on_frozen: +6.19982420 ± 0.15923854.

## Integrity scope and limits

The audit recomputes calibration quantiles and policy selection from saved source predictions, checks true-target and held-source exclusions, verifies every output-manifest hash, aligns target labels/orders to both matched comparators, and checks rejected predictions and scale preservation. The label-free archive hash and every array are compared with the scored archive.

The frozen code writes label-free NPZ files before invoking the target scorer. Artifact equality and the saved freeze records corroborate this design; hashes alone cannot independently prove the wall-clock order of operations. Batch decision JSON is finalized after scoring, while its label-free batch arrays are already saved before scoring. No claim of a trusted timestamp is made.

If adaptation is disabled, recovery is attributed to the selected static fallback. It is not evidence that adaptation became beneficial. Source selection has no no-harm guarantee on the true target.

