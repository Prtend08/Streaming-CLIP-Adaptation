# Raw-input online replay validation

Paired execution fidelity on reused data/orders, not independent efficacy or automatic-switch validation. PACS aggregates average four domains within each order; batch-one QuickDraw is single-order only. Current-batch encoding is shared across independent methods; timing is component-scoped.

Verified 26 streams, 156 method-runs, 4025 current-batch encoding events.
Maximum per-stream accuracy difference from cached replay: 0.00000662 percentage points.
Total adaptive prediction disagreements: 0.

| Dataset/batch and method | Orders | Raw mean ± SD (%) | Cached mean (%) |
|---|---:|---:|---:|
| PACS_b64/confidence_weighted | 5 | 97.5543 ± 0.0472 | 97.5543 |
| PACS_b64/matched_entropy | 5 | 97.5530 ± 0.0458 | 97.5530 |
| PACS_b64/pr_ema | 5 | 97.5689 ± 0.0428 | 97.5689 |
| PACS_b64/pr_frozen | 5 | 97.5819 ± 0.0689 | 97.5819 |
| PACS_b64/source_prototype | 5 | 95.6837 ± 0.0000 | 95.6837 |
| PACS_b64/zeroshot | 5 | 97.1905 ± 0.0000 | 97.1905 |
| QuickDraw_b1/confidence_weighted | 1 | 73.2000 (single order) | 73.2000 |
| QuickDraw_b1/matched_entropy | 1 | 73.2000 (single order) | 73.2000 |
| QuickDraw_b1/pr_ema | 1 | 73.2000 (single order) | 73.2000 |
| QuickDraw_b1/pr_frozen | 1 | 73.2000 (single order) | 73.2000 |
| QuickDraw_b1/source_prototype | 1 | 77.4333 (single order) | 77.4333 |
| QuickDraw_b1/zeroshot | 1 | 73.2000 (single order) | 73.2000 |
| QuickDraw_b64/confidence_weighted | 5 | 68.9733 ± 0.9702 | 68.9733 |
| QuickDraw_b64/matched_entropy | 5 | 69.7933 ± 0.8408 | 69.7933 |
| QuickDraw_b64/pr_ema | 5 | 69.0400 ± 0.9175 | 69.0400 |
| QuickDraw_b64/pr_frozen | 5 | 70.1000 ± 0.8396 | 70.1000 |
| QuickDraw_b64/source_prototype | 5 | 77.4333 ± 0.0000 | 77.4333 |
| QuickDraw_b64/zeroshot | 5 | 73.2000 ± 0.0000 | 73.2000 |
