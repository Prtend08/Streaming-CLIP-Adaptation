# PACS Art Painting, seed 100: measured gate failure

The gate accepts **15 of 32 batches** (960 of 2,048 images). In those accepted
batches, **5 originally correct zero-shot predictions become incorrect**,
while **3 originally incorrect predictions become correct**. The net loss is
therefore two correct predictions. Among accepted batches, five have a
negative net change, two a positive net change, and eight no net change.

All predictions in the 17 fallback batches match zero-shot exactly. The loss
comes from the accepted adaptation outputs, not a fallback implementation
error. Gate accuracy is **98.681640625% (2021/2048)** versus **98.779296875%
(2023/2048)** for zero-shot, a difference of **−0.09765625 percentage points**.
Always-on frozen PGR for the matched original pilot stream is 98.73046875%.

Suggested manuscript sentence: “The Art Painting failure at seed 100 reflects
errors in accepted updates: among 15 accepted batches, five correct zero-shot
predictions became incorrect and three errors were corrected, a net loss of
two images (−0.10 points); all fallback predictions were unchanged.”

This is an outcome accounting, not an inferred semantic or causal explanation
of why those images changed. It demonstrates that high batch-median source
reliability does not guarantee a beneficial update.

Raw counts, per-batch accounting, and input file hashes are saved in
`pacs_art_seed100_gate_failure.json`; `audit_gate_comparisons.py` reproduces
them from the original `gated_final` and matched raw-input `results` NPZs.
