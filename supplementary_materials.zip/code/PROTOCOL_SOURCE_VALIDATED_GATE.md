# Source-validated fallback and adaptation policy

Protocol date: 2026-09-29. Status: locked candidate revision for OfficeHome and TerraIncognita with LAION OpenCLIP ViT-B/16. This document describes a new experiment; it is not a result or a promise of improvement.

## Motivation and scientific scope

The existing source-correctness gate fails to prevent aggregate negative transfer on OfficeHome and TerraIncognita. Its score calibrates confidence/prototype agreement for correct source predictions, which is not the same as calibrating whether an entropy update will help. The revised policy adds an explicit source-only check of the value of the fallback classifier and of running adaptation.

This design was motivated by already observed benchmark failures. It is therefore **post-hoc method development**, even though the new selector never receives true-target labels and all choices below are fixed before inspecting the new candidate's target predictions. OfficeHome/Terra are reused benchmark families, not new independent validation datasets. The aim is to measure whether the candidate reduces the observed degradation. Success cannot be required as an outcome, and poor results must be retained.

## Locked settings

- Datasets: OfficeHome and TerraIncognita, four domains each, leave-one-domain-out evaluation.
- Backbone: the same LAION OpenCLIP ViT-B/16 checkpoint and aligned feature tensors as the existing gate replay.
- Source-validation orders: exactly seeds **7000, 7001, 7002**.
- Target evaluation orders: exactly seeds **100–109** per target domain.
- Batch size 64, including the final partial batch.
- Frozen PGR branch: eight Adam updates, learning rate 5e-4, retained fraction 0.9, residual gradient clipping 1.0, residual and optimizer reset each batch, frozen source prototypes, and retained scalar log-scale. Preserve the existing `ResidualAdapter` initialization and implementation for this candidate comparison.
- Gate score: zero-shot normalized confidence × positive predicted-class source-prototype cosine at effective scale 100. The batch score is `torch.median`, the lower middle value for even batch size.
- Gate threshold: NumPy linear 25th percentile of correct held-out source-example scores. The quantile is fixed at **0.25**. There is no quantile, update-step, margin, or order-count sweep.
- Equal-domain macro averaging is used for selection and reporting. Do not pool differently sized domains to choose a policy.
- Ties select the simpler/no-update action as specified below. No threshold is adjusted after reading target outcomes.

## Data boundaries for each true target

For true target domain `d`, let `S` be the three remaining allowed source domains. Fit the entire selector from `(features, labels)` in `S` only. The true target domain's features and labels must not enter source prototype construction, source threshold calibration, fallback selection, or adaptation-enable selection.

For each source-validation held-out domain `h` in `S`, let `R = S minus {h}`. Build the validation prototype bank from `R` only. Obtain the validation gate threshold by applying the existing leave-one-source-domain-out calibration **within `R`**: hold out one of the two domains of `R`, build its prototype bank from the remaining domain, score the held-out examples, and pool scores of correct predictions. Thus neither `h` nor true target `d` contributes to that fold's prototypes or threshold.

Predict the examples in `h` before using their labels to compute validation accuracy. Labels in `h` are allowed source labels for policy selection, but they are absent from the adaptation and gate runtime interfaces. Do not reuse the core target-`h` prediction files for these folds: the old core source bank for `h` contains true target `d`, so those files are not valid source-only validation artifacts for this outer target.

## Stage 1: select a static fallback

On each source-validation fold `h`, compare:

1. Unchanged zero-shot CLIP (`argmax(x @ w.T)`).
2. Static source-prototype classification (`argmax(x @ mu_R.T)`), with `mu_R` computed from the two training source domains only.

Let `delta_static[h]` be prototype accuracy minus zero-shot accuracy on `h`, in percentage points. Select the source-prototype fallback only if **every** source-fold delta is nonnegative and the equal-domain mean delta is strictly positive. Otherwise select zero-shot. Equality of the macro means selects zero-shot.

This rule uses no target result to prefer the 77.43% QuickDraw classifier or any other retrospectively better target strategy. For the present experiment it operates only on the allowed OfficeHome/Terra source folds.

## Stage 2: decide whether to enable the fixed gate

For each `h` and each source-validation seed 7000–7002, run the complete sequential gate with `mu_R` and the nested source-only threshold. On accepted batches run frozen PGR. On rejected batches emit the Stage-1-selected static fallback, without changing the retained adaptation state.

Compute the accuracy difference between the full gated stream and the selected static fallback on the same held-out domain and order. Average the three order differences **within each source domain**. Enable the gate only if every source-domain mean difference is nonnegative and their equal-domain macro mean is strictly positive. Otherwise disable adaptation for the entire true-target stream and use the selected static fallback. A zero macro difference selects no adaptation.

The criterion concerns the three-order **mean** for each source domain. It does not require, and must not be described as establishing, nonnegative gain on every validation order or batch. Three permutations quantify order sensitivity on the same samples; they are not three independent datasets.

Both fallback selection and gate-enable selection use the allowed source-validation folds. These are policy-selection data, not an unbiased independent estimate of the selected policy's performance. The final target predictions provide the post-selection outcome, but their benchmark families were already involved in development.

## Final target replay

After saving the selected fallback, enable/disable decision, fold accuracies and reasons:

1. Build the final frozen prototype bank using all three allowed source domains `S`.
2. If the policy enables the gate, calibrate its final numeric threshold from `S` by the same leave-one-source-domain-out, correct-source, fixed-0.25 rule. Final numeric thresholds may differ by true target because permitted source sets differ.
3. For each locked target order, supply only target features and order indices to the prediction function. If adaptation is disabled by Stage 2, emit the selected static fallback for every batch. Otherwise run the gate exactly as validated, with the final source bank/threshold.
4. Save label-free predictions and batch decision arrays before invoking the separate scorer with true-target labels. Finalize the human-readable batch JSON after scoring.

The calibration/production bank sizes differ: a validation fold uses two-source prototypes, its internal threshold calibration uses one-source prototypes, and final deployment uses three-source prototypes with two-source calibration banks. This is an unavoidable small-domain limitation of the present LOSO design, and is not claimed to ensure calibration transfer.

## Implementation and integrity requirements

- A fitting function such as `fit_source_policy(w, source_cache)` should only receive the source subset. Assert that the true target ID is absent from every source/calibration manifest.
- A runtime function such as `apply_policy(w, mu, tau, fallback_id, gate_enabled, target_x, order)` must not accept target labels. Keep final scoring separate.
- Freeze/cache hashes and verify that image/label/order alignment matches existing comparison runs. Record code hash, protocol hash, checkpoint/feature-manifest hashes, environment, seeds, dtype and CUDA math settings.
- Pin the same determinism settings as the main replay (`allow_tf32=False`, `cudnn.allow_tf32=False`, `cudnn.benchmark=False`) and record library/GPU versions.
- Each source fold stores its permitted source names, nested-calibration domains, threshold, source counts, static accuracies, each order's gated accuracy and chosen policy. The final selector must be reconstructable from these records without target scores.
- Each target batch records reliability median, numeric threshold, selected fallback, dataset-level gate-enable decision, accept/fallback action, and scale before/after. A fallback must preserve scale. Save order and prediction hashes.
- Two gate candidates that differ only in the static fallback classifier have identical accept decisions and state trajectories, because fallback changes no state. One adaptive replay may therefore produce both candidate prediction arrays. In contrast, changing quantile or skip decisions changes retained scale: do not splice always-on predictions to simulate such a gated policy.
- Save all 80 final target-stream records, including policies that choose no adaptation. No omitted failures, target-based seed filtering, or rerun-until-positive logic is allowed. Preserve the earlier gate and always-on negative outcomes in separate namespaces.

## Budget and comparisons

The fixed source-validation budget is **72 adaptive fold streams**: two datasets × four true targets × three source-heldout folds × three source-validation orders. Static zero-shot/prototype scoring adds no gradient optimization. Final evaluation is **80 target streams**: two datasets × four true targets × ten orders. A disabled policy can be evaluated directly without unnecessary adaptation, while still saving a completed result for every locked stream. Existing feature tensors avoid repeated image encoding.

Report the new selected policy against zero-shot, the static source prototype, the Stage-1-selected fallback, always-on frozen PGR, and the original fixed-quantile gate, using matched sample/order alignment. The original methods' stored outputs can be used as target comparators after alignment checks; they cannot be used to select the new policy. Include per-domain and macro accuracy, chosen fallback, enable/disable decision, accepted/fallback batch counts, and differences versus zero-shot and the original gate. Order SD/paired intervals describe conditional order variation only. Report selection outcomes as well as accuracy so that improvement caused entirely by disabling adaptation is visible.

## Interpretation rules

- If the selected policy recovers zero-shot by disabling adaptation, describe it as **baseline recovery or avoidance of observed degradation**, not evidence that PGR adaptation became successful.
- If a source-prototype fallback is selected and helps, attribute the result to the source-selected static classifier unless the adapted branch adds a separate measured benefit.
- If the new policy still loses on the true target, retain the result and identify the failed source-to-target selection transfer. Do not change this locked rule based on that outcome within the same experiment.
- No result here establishes a no-harm guarantee, deployment safety, measured HCI benefit, or independent new-dataset generalization. A future untouched task would be needed for a stronger validation claim.

## Artifact wording clarification after execution

On 2026-09-29, step 4 was clarified to distinguish the label-free decision arrays saved before scoring from the human-readable JSON finalized afterwards. This changes no selection rule, seeds, threshold, adapter, or result. The launch-time wording is preserved in `PROTOCOL_SOURCE_VALIDATED_GATE_as_launched.md`; the frozen executable and its hashes are unchanged.
