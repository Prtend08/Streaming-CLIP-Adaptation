"""Independently audit and aggregate the locked post-hoc source policy outputs.

Reads raw outputs and existing matched comparators only. Does not rerun models,
alter source-policy choices, or overwrite raw runs. Default input is the local
synced source_validated_20260929 directory; invoke only after it is downloaded.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np


WORKSPACE = Path(__file__).resolve().parents[1]
SYNCED = WORKSPACE / 'revision_20260901' / 'synced'
DOMAINS = {'OfficeHome': ['Art', 'Clipart', 'Product', 'Real_World'],
           'TerraIncognita': ['location_100', 'location_38', 'location_43', 'location_46']}
ALIASES = {'OfficeHome': 'office', 'TerraIncognita': 'terra'}
SEEDS = list(range(100, 110))
CV_SEEDS = [7000, 7001, 7002]
PRED_KEYS = ['zeroshot_prediction', 'source_prototype_prediction',
             'gate_zeroshot_prediction', 'gate_source_prototype_prediction']
METHODS = ['policy', 'zeroshot', 'source_prototype', 'selected_fallback',
           'original_gate', 'always_on_frozen']


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load_npz(path):
    with np.load(path, allow_pickle=False) as data:
        return {key: data[key].copy() for key in data.files}


def save_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def relative_file(root, path):
    """Both Linux-written and Windows-written relative names are accepted."""
    relative = Path(str(path).replace('\\', '/'))
    candidate = (root / relative).resolve()
    if not candidate.is_relative_to(root.resolve()):
        raise ValueError(f'Artifact path leaves expected directory: {path}')
    return candidate


class Audit:
    def __init__(self):
        self.counts = Counter()
        self.errors = []
        self.warnings = []
        self.references = {}

    def check(self, condition, category, context):
        self.counts[category] += 1
        if not bool(condition):
            self.errors.append({'check': category, 'context': str(context)})
        return bool(condition)

    def equal(self, first, second, category, context):
        return self.check(np.array_equal(first, second), category, context)

    def close(self, first, second, category, context, atol=1e-10):
        return self.check(np.isclose(first, second, rtol=0, atol=atol), category, context)

    def file(self, path, expected, context):
        path = Path(path)
        if not self.check(path.is_file(), 'artifact_exists', context):
            return False
        okay = self.check(sha256(path) == expected['sha256'], 'artifact_sha256', context)
        if 'bytes' in expected:
            okay &= self.check(path.stat().st_size == expected['bytes'], 'artifact_bytes', context)
        return okay


def metric(pred, labels):
    correct = int(np.count_nonzero(pred == labels))
    return {'n': len(labels), 'correct': correct, 'accuracy': correct * 100. / len(labels)}


def metric_check(audit, pred, labels, logged, context):
    actual = metric(pred, labels)
    audit.check(logged['n'] == actual['n'], 'metric_n', context)
    audit.check(logged['correct'] == actual['correct'], 'metric_integer_correct', context)
    audit.close(logged['accuracy'], actual['accuracy'], 'metric_accuracy', context)
    return actual


def decision_from_raw(folds, tau):
    """Independent reconstruction from integer counts, not manifest decisions."""
    static_deltas = [sum(order['source_prototype_prediction']['correct'] -
                         order['zeroshot_prediction']['correct'] for order in f['orders'])
                     * 100. / (len(CV_SEEDS) * f['n']) for f in folds]
    fallback = ('source_prototype' if min(static_deltas) >= 0 and
                sum(static_deltas) > 0 else 'zeroshot')
    gate_deltas = [sum(order['gate_' + fallback + '_prediction']['correct'] -
                       order[fallback + '_prediction']['correct'] for order in f['orders'])
                   * 100. / (len(CV_SEEDS) * f['n']) for f in folds]
    rule_pass = min(gate_deltas) >= 0 and sum(gate_deltas) > 0
    return {'fallback': fallback, 'gate_enabled': bool(rule_pass and tau is not None),
            'source_prototype_minus_zeroshot_per_source_pp': static_deltas,
            'source_prototype_minus_zeroshot_macro_pp': float(np.mean(static_deltas)),
            'gate_minus_selected_fallback_per_source_pp': gate_deltas,
            'gate_minus_selected_fallback_macro_pp': float(np.mean(gate_deltas)),
            'fallback_rule_passed': fallback == 'source_prototype',
            'gate_rule_passed': bool(rule_pass), 'source_order': [f['held_source'] for f in folds]}


def old_reference(synced, dataset, domain):
    return synced / 'core' / 'runs' / dataset / 'ViT-B-16' / (domain + '_reliability.npz')


def check_stream(audit, arrays, batches, threshold, policy_enabled, context,
                 selected_fallback=None, validation=False):
    labels, order = arrays['labels'], arrays['order']
    n = len(labels)
    audit.equal(np.sort(order), np.arange(n), 'order_full_permutation', context)
    nb = (n + 63) // 64
    audit.check(len(batches) == nb, 'batch_record_count', context)
    for key in ['gate', 'score_pass', 'batch_score', 'scale_before', 'scale_after']:
        audit.check(len(arrays[key]) == nb, 'batch_array_length', f'{context}/{key}')
        audit.check(np.isfinite(arrays[key]).all(), 'batch_array_finite', f'{context}/{key}')
    audit.close(arrays['scale_before'][0], float(np.float32(4.6052)), 'original_initial_scale', context, atol=0)
    for key in (PRED_KEYS if validation else ['prediction', 'zeroshot_prediction', 'source_prototype_prediction']):
        audit.check(arrays[key].shape == labels.shape, 'prediction_shape', f'{context}/{key}')
        audit.check(np.issubdtype(arrays[key].dtype, np.integer), 'prediction_integer_dtype', f'{context}/{key}')
    audit.check(np.isfinite(arrays['sample_score']).all(), 'sample_score_finite', context)
    audit.check(len(arrays['sample_score']) == n, 'sample_score_length', context)
    rejected_samples = 0
    for i, batch in enumerate(batches):
        ctx = f'{context}/batch{i}'
        indices = order[i * 64:(i + 1) * 64]
        audit.check(batch['batch'] == i and batch['start'] == i * 64 and batch['n'] == len(indices),
                    'batch_range', ctx)
        audit.equal(batch['sample_indices'], indices, 'batch_sample_indices', ctx)
        score = float(np.partition(arrays['sample_score'][indices], (len(indices) - 1) // 2)[(len(indices) - 1) // 2])
        audit.close(score, arrays['batch_score'][i], 'lower_median_recomputed', ctx, atol=0)
        audit.close(score, batch['batch_median_score'], 'batch_score_json', ctx, atol=0)
        audit.check(batch['threshold'] == threshold, 'batch_threshold', ctx)
        passes = threshold is not None and score >= threshold
        accepted = bool(policy_enabled and passes)
        audit.check(bool(arrays['score_pass'][i]) == passes and batch['score_pass'] == passes,
                    'score_threshold_rule', ctx)
        audit.check(bool(arrays['gate'][i]) == accepted and batch['gate_enabled'] == accepted,
                    'gate_policy_rule', ctx)
        audit.check(batch['policy_gate_allowed'] == policy_enabled, 'batch_policy_enabled', ctx)
        before, after = arrays['scale_before'][i], arrays['scale_after'][i]
        audit.close(before, batch['scale_before'], 'scale_before_json', ctx, atol=0)
        audit.close(after, batch['scale_after'], 'scale_after_json', ctx, atol=0)
        if i:
            audit.close(before, arrays['scale_after'][i-1], 'scale_continuity', ctx, atol=0)
        audit.check(batch['prototype_change_l2'] == 0, 'frozen_prototypes_log', ctx)
        audit.check(batch['predictions_committed_before_next_batch'], 'commit_before_next_batch_log', ctx)
        if not accepted:
            rejected_samples += len(indices)
            audit.close(before, after, 'fallback_preserves_scale', ctx, atol=0)
            audit.check(batch['state_action'] == 'preserve_state', 'fallback_state_log', ctx)
            if validation:
                for method in ['zeroshot', 'source_prototype']:
                    audit.equal(arrays['gate_' + method + '_prediction'][indices],
                                arrays[method + '_prediction'][indices], 'validation_fallback_exact', ctx + '/' + method)
            else:
                audit.equal(arrays['prediction'][indices], arrays[selected_fallback + '_prediction'][indices],
                            'selected_fallback_exact', ctx)
        elif validation:
            audit.equal(arrays['gate_zeroshot_prediction'][indices],
                        arrays['gate_source_prototype_prediction'][indices], 'shared_adaptive_prediction_exact', ctx)
    return rejected_samples


def check_calibration(audit, directory, permitted, dataset, synced, context):
    record = read_json(directory / 'calibration.json')
    arrays = load_npz(directory / 'calibration_scores.npz')
    audit.file(directory / 'calibration_scores.npz', record['scores'], context + '/scores')
    audit.check(sorted(record['source_domains']) == sorted(permitted), 'calibration_source_exclusion', context)
    audit.check(record['target_labels_used'] is False and record['quantile'] == 0.25,
                'calibration_fixed_label_boundary', context)
    audit.check(sorted(np.unique(arrays['held_domain']).tolist()) == sorted(permitted),
                'calibration_held_domains', context)
    audit.check(len(record['folds']) == len(permitted), 'calibration_fold_count', context)
    audit.check(sorted(f['held_source'] for f in record['folds']) == sorted(permitted),
                'calibration_fold_inventory', context)
    for fold in record['folds']:
        held = fold['held_source']
        audit.check(held in permitted and sorted(fold['prototype_sources']) == sorted(set(permitted) - {held}),
                    'nested_calibration_prototype_exclusion', context + '/' + held)
        mask = arrays['held_domain'] == held
        ref = load_npz(old_reference(synced, dataset, held))
        audit.equal(arrays['sample_index'][mask], np.arange(len(ref['labels'])),
                    'calibration_sample_indices', context + '/' + held)
        audit.equal(arrays['labels'][mask], ref['labels'], 'calibration_labels_alignment', context + '/' + held)
        audit.equal(arrays['prediction'][mask], ref['predictions'], 'calibration_zeroshot_alignment', context + '/' + held)
        audit.check(fold['n'] == int(mask.sum()) and fold['correct'] ==
                    int(np.count_nonzero(arrays['prediction'][mask] == arrays['labels'][mask])),
                    'calibration_fold_counts', context + '/' + held)
    correct = arrays['prediction'] == arrays['labels']
    audit.equal(arrays['correct'].astype(bool), correct, 'calibration_correct_mask', context)
    values = arrays['score'][correct].astype(np.float64)
    threshold = float(np.quantile(values, 0.25)) if len(values) else None
    audit.check(record['threshold'] == threshold, 'calibration_quantile_recomputed', context)
    audit.check(record['n_source_correct'] == len(values) and record['usable'] == (threshold is not None),
                'calibration_correct_count', context)
    return threshold


def audit_selection(audit, base, synced, dataset, target, validation_orders):
    directory = base / 'selection' / dataset / target
    manifest = read_json(directory / 'selection_manifest.json')
    marker = read_json(directory / 'FROZEN_BEFORE_TARGET.json')
    source = sorted(set(DOMAINS[dataset]) - {target})
    context = dataset + '/' + target
    audit.check(manifest['source_domains'] == source and target not in source,
                'selector_true_target_exclusion', context)
    audit.check(manifest['target_labels_used_for_selection'] is False, 'selector_label_boundary', context)
    audit.check(manifest['validation_seeds'] == CV_SEEDS, 'selector_validation_seeds', context)
    audit.check(marker['target'] == target and marker['frozen_before_target_tensor_load'] is True,
                'frozen_marker', context)
    audit.check(marker['selection_sha256'] == sha256(directory / 'selection_manifest.json'),
                'frozen_selection_hash', context)
    audit.check(marker['unix'] >= manifest['frozen_at_unix'], 'frozen_marker_time_consistency', context)
    audit.check([f['held_source'] for f in manifest['folds']] == source, 'selection_fold_inventory', context)
    raw_folds = []
    for held in source:
        fold_directory = directory / 'validation' / held
        train = sorted(set(source) - {held})
        tau = check_calibration(audit, fold_directory / 'inner_calibration', train, dataset, synced,
                                context + '/validation/' + held)
        orders = []
        static_previous = None
        for seed in CV_SEEDS:
            stem = fold_directory / f'validation_{seed}'
            record = read_json(stem.with_suffix('.json'))
            arrays = load_npz(stem.with_suffix('.npz'))
            ctx = context + '/' + held + '/' + str(seed)
            audit.check(record['complete'] and record['held_source'] == held and record['seed'] == seed,
                        'validation_identity_complete', ctx)
            audit.check(record['prototype_sources'] == train and record['threshold'] == tau,
                        'validation_bank_target_and_held_exclusion', ctx)
            audit.file(relative_file(directory, record['predictions']['path']), record['predictions'], ctx)
            audit.check(record['order_sha256'] == hashlib.sha256(arrays['order'].tobytes()).hexdigest(),
                        'validation_order_hash', ctx)
            ref = load_npz(old_reference(synced, dataset, held))
            audit.equal(arrays['labels'], ref['labels'], 'validation_labels_alignment', ctx)
            audit.equal(arrays['zeroshot_prediction'], ref['predictions'], 'validation_zeroshot_alignment', ctx)
            order_key = dataset + '/' + held + '/' + str(seed)
            if order_key in validation_orders:
                audit.equal(arrays['order'], validation_orders[order_key], 'validation_order_cross_selector', ctx)
            else:
                validation_orders[order_key] = arrays['order']
            if static_previous is not None:
                audit.equal(arrays['source_prototype_prediction'], static_previous,
                            'validation_static_order_invariance', ctx)
            static_previous = arrays['source_prototype_prediction']
            check_stream(audit, arrays, record['batches'], tau, True, ctx, validation=True)
            audit.check(record['accepted_batches'] == int(arrays['gate'].sum()), 'validation_accepted_count', ctx)
            raw_metrics = {key: metric_check(audit, arrays[key], arrays['labels'], record['metrics'][key],
                                             ctx + '/' + key) for key in PRED_KEYS}
            audit.check(record['n'] == len(arrays['labels']), 'validation_n', ctx)
            orders.append({'seed': seed, **raw_metrics})
        actual = {'held_source': held, 'n': len(arrays['labels']), 'prototype_sources': train,
                  'inner_threshold': tau, 'orders': orders}
        logged = next(f for f in manifest['folds'] if f['held_source'] == held)
        audit.check(logged['held_source'] == actual['held_source'] and logged['n'] == actual['n'] and
                    logged['prototype_sources'] == train and logged['inner_threshold'] == tau,
                    'selection_fold_summary', ctx)
        for logged_order, actual_order in zip(logged['orders'], orders):
            audit.check(logged_order['seed'] == actual_order['seed'], 'selection_summary_seed', ctx)
            for key in PRED_KEYS:
                audit.check(logged_order[key]['correct'] == actual_order[key]['correct'],
                            'selection_summary_correct', ctx + '/' + key)
                audit.close(logged_order[key]['accuracy'], actual_order[key]['accuracy'],
                            'selection_summary_accuracy', ctx + '/' + key)
        audit.check(len(logged['orders']) == 3, 'selection_summary_order_count', ctx)
        raw_folds.append(actual)
    tau = check_calibration(audit, directory / 'deployment_calibration', source, dataset, synced,
                            context + '/deployment')
    audit.check(manifest['deployment_threshold'] == tau, 'deployment_threshold_manifest', context)
    recomputed = decision_from_raw(raw_folds, tau)
    for key, value in recomputed.items():
        logged = manifest['decision'][key]
        if isinstance(value, float) or (isinstance(value, list) and value and isinstance(value[0], float)):
            audit.check(np.allclose(value, logged, rtol=0, atol=1e-12), 'selection_rule_recomputed', context + '/' + key)
        else:
            audit.check(value == logged, 'selection_rule_recomputed', context + '/' + key)
    return {'source_domains': source, 'deployment_threshold': tau, 'decision': recomputed,
            'selection_sha256': sha256(directory / 'selection_manifest.json'),
            'source_validation': raw_folds, 'frozen_at_unix': manifest['frozen_at_unix']}


def stats(values):
    values = np.asarray(values, dtype=float)
    # Repeated identical static accuracies have exactly zero order variance;
    # avoid reporting reduction-roundoff as an empirical SD around 1e-14.
    if np.all(values == values[0]):
        return {'mean': float(values[0]), 'sample_sd': 0.0, 'orders': len(values)}
    return {'mean': float(values.mean()), 'sample_sd': float(values.std(ddof=1)), 'orders': len(values)}


def summarize_rows(rows):
    summary = {'methods': {key: stats([r['accuracy'][key] for r in rows]) for key in METHODS},
               'paired_policy_differences_pp': {key: stats([r['accuracy']['policy'] - r['accuracy'][key] for r in rows])
                                                for key in METHODS if key != 'policy'},
               'accepted_batches': sum(r['accepted_batches'] for r in rows),
               'total_batches': sum(r['total_batches'] for r in rows)}
    summary['rejected_batches'] = summary['total_batches'] - summary['accepted_batches']
    summary['accepted_fraction'] = summary['accepted_batches'] / summary['total_batches']
    # Domain-level rows have integer correctness; macro rows use unrounded means.
    summary['order_win_tie_loss_vs_zeroshot'] = {
        'win': sum(r['accuracy']['policy'] > r['accuracy']['zeroshot'] for r in rows),
        'tie': sum(r['accuracy']['policy'] == r['accuracy']['zeroshot'] for r in rows),
        'loss': sum(r['accuracy']['policy'] < r['accuracy']['zeroshot'] for r in rows)}
    return summary


def audit_target(audit, base, synced, dataset, target, seed, selection, static_cache):
    stem = base / 'runs' / dataset / 'ViT-B-16' / f'{target}__source_validated__{seed}'
    record = read_json(stem.with_suffix('.json'))
    arrays = load_npz(stem.with_suffix('.npz'))
    blind_path = stem.with_suffix('.label_free.npz')
    blind = load_npz(blind_path)
    ctx = f'{dataset}/{target}/{seed}'
    audit.check(record['complete'] and record['dataset'] == dataset and record['domain'] == target and
                record['seed'] == seed and record['backbone'] == 'ViT-B-16', 'target_identity_complete', ctx)
    audit.check(record['target_labels_used_for_policy'] is False, 'target_policy_label_boundary', ctx)
    audit.file(relative_file(base, record['prediction_file']), {'sha256': record['prediction_sha256']}, ctx)
    audit.file(relative_file(base, record['label_free_prediction_file']),
                {'sha256': record['label_free_prediction_sha256']}, ctx + '/label_free')
    audit.check('labels' not in blind and set(blind) == set(arrays) - {'labels'}, 'label_free_keys', ctx)
    for key in blind:
        audit.equal(blind[key], arrays[key], 'label_free_scored_array_identity', ctx + '/' + key)
    audit.check(record['order_sha256'] == hashlib.sha256(arrays['order'].tobytes()).hexdigest(),
                'target_order_hash', ctx)
    selection_path = relative_file(base, record['selection_file'])
    audit.check(selection_path == (base / 'selection' / dataset / target / 'selection_manifest.json').resolve(),
                'target_selection_path', ctx)
    audit.check(record['selection_sha256'] == selection['selection_sha256'] == sha256(selection_path),
                'target_frozen_selection_sha', ctx)
    decision = selection['decision']
    audit.check(record['fallback'] == decision['fallback'] and record['policy_gate_enabled'] == decision['gate_enabled']
                and record['threshold'] == selection['deployment_threshold'], 'target_frozen_choice', ctx)
    check_stream(audit, arrays, record['batches'], record['threshold'], decision['gate_enabled'], ctx,
                 selected_fallback=decision['fallback'])
    audit.check(record['enabled_batches'] == int(arrays['gate'].sum()) and
                record['total_batches'] == len(arrays['gate']), 'target_batch_totals', ctx)
    audit.close(record['enabled_fraction'], arrays['gate'].mean(), 'target_enabled_fraction', ctx)
    if not decision['gate_enabled']:
        audit.equal(arrays['prediction'], arrays[decision['fallback'] + '_prediction'],
                    'disabled_policy_static_exact', ctx)
        audit.check(not arrays['gate'].any(), 'disabled_policy_no_adaptation', ctx)
    ref_path = old_reference(synced, dataset, target)
    ref = load_npz(ref_path)
    audit.equal(arrays['labels'], ref['labels'], 'target_reliability_labels', ctx)
    audit.equal(arrays['zeroshot_prediction'], ref['predictions'], 'target_old_zeroshot_exact', ctx)
    cache_key = (dataset, target)
    if cache_key in static_cache:
        audit.equal(arrays['source_prototype_prediction'], static_cache[cache_key], 'target_static_order_invariance', ctx)
    else:
        static_cache[cache_key] = arrays['source_prototype_prediction']
    paths = {
        'original_gate': synced / 'online_e2e' / f'gated_{ALIASES[dataset]}_20260929' / 'runs' / dataset /
                         'ViT-B-16' / f'{target}__pgr_gate__{seed}.npz',
        'always_on_frozen': synced / 'core' / 'runs' / dataset / 'ViT-B-16' / f'{target}__pr_frozen__{seed}.npz'}
    predictions = {'policy': arrays['prediction'], 'zeroshot': arrays['zeroshot_prediction'],
                   'source_prototype': arrays['source_prototype_prediction'],
                   'selected_fallback': arrays[decision['fallback'] + '_prediction']}
    for method, path in paths.items():
        old = load_npz(path)
        audit.equal(arrays['order'], old['order'], 'matched_comparator_order', ctx + '/' + method)
        audit.equal(arrays['labels'], old['labels'], 'matched_comparator_labels', ctx + '/' + method)
        predictions[method] = old['prediction']
        audit.references[str(path.relative_to(synced))] = {'sha256': sha256(path), 'bytes': path.stat().st_size}
    audit.references[str(ref_path.relative_to(synced))] = {'sha256': sha256(ref_path), 'bytes': ref_path.stat().st_size}
    for key in ['prediction', 'zeroshot_prediction', 'source_prototype_prediction']:
        metric_check(audit, arrays[key], arrays['labels'], record['metrics'][key], ctx + '/' + key)
    metric_check(audit, arrays['prediction'], arrays['labels'], record, ctx + '/main')
    computed = {key: metric(value, arrays['labels']) for key, value in predictions.items()}
    return {'dataset': dataset, 'domain': target, 'seed': seed, 'n': len(arrays['labels']),
            'accuracy': {key: value['accuracy'] for key, value in computed.items()},
            'correct': {key: value['correct'] for key, value in computed.items()},
            'fallback': decision['fallback'], 'policy_gate_enabled': decision['gate_enabled'],
            'accepted_batches': int(arrays['gate'].sum()), 'total_batches': len(arrays['gate']),
            'score_pass_batches': int(arrays['score_pass'].sum())}


def audit_environment(audit, base, synced, protocol, restored_root):
    env = read_json(base / 'environment.json')
    audit.check(env['captured_before_execution'] is True, 'environment_capture_phase_log', 'environment')
    audit.check(env['num_threads'] == 4 and not env['matmul_allow_tf32'] and not env['cudnn_allow_tf32'] and
                not env['cudnn_benchmark'], 'environment_math_settings', 'environment')
    audit.check(env['protocol_sha256'] == sha256(base / 'protocol.json'), 'environment_protocol_hash', 'environment')
    candidates = {'policy': Path(__file__).with_name('source_validated_gate.py'),
                  'original_adapter': synced / 'run_revision.py'}
    for name, local_path in candidates.items():
        audit.file(local_path, env['scripts'][name], 'environment/script/' + name)
    expected = len(protocol['datasets']) * 5
    audit.check(len(env['input_tensors']) == expected, 'input_tensor_inventory', 'environment')
    for name, info in env['input_tensors'].items():
        parts = str(name).replace('\\', '/').split('/')
        dataset = next((d for d in protocol['datasets'] if d in parts), None)
        if not audit.check(dataset is not None, 'input_tensor_dataset', name):
            continue
        local = restored_root / dataset / 'ViT-B-16' / parts[-1]
        audit.file(local, info, 'environment/tensor/' + dataset + '/' + parts[-1])
    return env


def make_markdown(report, integrity):
    status = 'PASS' if integrity['passed'] else 'FAIL'
    lines = ['# Post-hoc source-validated gate audit', '', f"Audit UTC: {integrity['created_utc']}. Status: **{status}**.", '',
             'This is a new post-hoc policy developed after the earlier benchmark outcomes were known. '
             'The earlier gate and always-on results remain unchanged. Source-only selection does not make these '
             'reused benchmark families independent confirmation.', '',
             f"Inventory: {integrity['inventory']['target_runs']} target streams, "
             f"{integrity['inventory']['validation_runs']} source-validation streams, "
             f"{integrity['inventory']['selections']} policy selections, and "
             f"{integrity['inventory']['label_free_files']} target label-free archives.", '',
             'All reported SDs are sample SDs across ten matched orders. Macro SD uses the ten equal-domain '
             'macro accuracies, not forty pooled domain/order rows. These orders reuse the same examples.', '']
    for dataset, result in report['datasets'].items():
        lines.extend(['## ' + dataset, '', '| Domain | Policy ± SD | ZS | Source prototype | Original gate | Always-on | Fallback; gate allowed | Accepted |',
                      '|---|---:|---:|---:|---:|---:|---|---:|'])
        for domain, data in list(result['domains'].items()) + [('Macro', result['macro'])]:
            methods = data['methods']
            choice = (data['selection']['decision']['fallback'] + '; ' + str(data['selection']['decision']['gate_enabled'])) if domain != 'Macro' else 'per domain'
            lines.append(f"| {domain} | {methods['policy']['mean']:.6f} ± {methods['policy']['sample_sd']:.6f} | "
                         f"{methods['zeroshot']['mean']:.6f} | {methods['source_prototype']['mean']:.6f} | "
                         f"{methods['original_gate']['mean']:.6f} | {methods['always_on_frozen']['mean']:.6f} | "
                         f"{choice} | {data['accepted_batches']}/{data['total_batches']} |")
        diffs = result['macro']['paired_policy_differences_pp']
        lines.extend(['', 'Macro paired changes (percentage points): ' + '; '.join(
            f"vs {key}: {diffs[key]['mean']:+.8f} ± {diffs[key]['sample_sd']:.8f}" for key in ['zeroshot', 'original_gate', 'always_on_frozen']) + '.', ''])
    lines.extend(['## Integrity scope and limits', '',
                  'The audit recomputes calibration quantiles and policy selection from saved source predictions, '
                  'checks true-target and held-source exclusions, verifies every output-manifest hash, aligns target '
                  'labels/orders to both matched comparators, and checks rejected predictions and scale preservation. '
                  'The label-free archive hash and every array are compared with the scored archive.', '',
                  'The frozen code writes label-free NPZ files before invoking the target scorer. Artifact equality '
                  'and the saved freeze records corroborate this design; hashes alone cannot independently prove '
                  'the wall-clock order of operations. Batch decision JSON is finalized after scoring, while '
                  'its label-free batch arrays are already saved before scoring. No claim of a trusted timestamp is made.', '',
                  'If adaptation is disabled, recovery is attributed to the selected static fallback. It is not '
                  'evidence that adaptation became beneficial. Source selection has no no-harm guarantee on the true target.', ''])
    if integrity['errors']:
        lines.extend(['## Failed checks', ''] + [f"- {e['check']}: {e['context']}" for e in integrity['errors']])
    if integrity['warnings']:
        lines.extend(['## Notes', ''] + ['- ' + w for w in integrity['warnings']])
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=SYNCED / 'online_e2e' / 'source_validated_20260929')
    parser.add_argument('--synced-root', type=Path, default=SYNCED)
    parser.add_argument('--restored-features', type=Path, default=WORKSPACE / 'revision_20260929' / 'restored_features')
    parser.add_argument('--report', type=Path, default=SYNCED / 'reports' / 'source_validated_gate_20260929.json')
    args = parser.parse_args()
    base, synced = args.input.resolve(), args.synced_root.resolve()
    if not (base / 'completion.json').is_file():
        raise SystemExit('Missing completion.json; wait for the complete download. No audit artifacts written.')
    audit = Audit()
    protocol, completion = read_json(base / 'protocol.json'), read_json(base / 'completion.json')
    manifest = read_json(base / 'output_manifest.json')
    audit.check(completion['complete'], 'experiment_complete', 'completion')
    audit.check(completion['output_manifest_sha256'] == sha256(base / 'output_manifest.json'),
                'completion_manifest_hash', 'completion')
    for relative, expected in manifest.items():
        audit.file(relative_file(base, relative), expected, 'output_manifest/' + relative)
    manifest_paths = {relative_file(base, relative) for relative in manifest}
    required = [base / 'protocol.json', base / 'environment.json']
    required += [p for directory in ['runs', 'selection'] for p in (base / directory).rglob('*') if p.is_file()]
    for path in required:
        audit.check(path.resolve() in manifest_paths, 'raw_artifact_manifest_coverage', str(path.relative_to(base)))
    audit.check(not (base / 'failure.json').exists(), 'no_failure_record', 'completion')
    audit.check(protocol['datasets'] == list(DOMAINS), 'locked_dataset_inventory', 'protocol')
    audit.check(protocol['validation_seeds'] == CV_SEEDS and protocol['target_seeds'] == SEEDS and
                protocol['batch_size'] == 64 and protocol['quantile'] == 0.25 and
                protocol['target_labels_used_for_policy'] is False, 'locked_protocol_settings', 'protocol')
    inventory = {'target_runs': len(list((base / 'runs').rglob('*.json'))),
                 'validation_runs': len(list((base / 'selection').rglob('validation_*.json'))),
                 'selections': len(list((base / 'selection').rglob('selection_manifest.json'))),
                 'label_free_files': len(list((base / 'runs').rglob('*.label_free.npz'))),
                 'validation_npz': len(list((base / 'selection').rglob('validation_*.npz'))),
                 'scored_target_npz': len([p for p in (base / 'runs').rglob('*.npz') if not p.name.endswith('.label_free.npz')])}
    for key, expected in [('target_runs', 80), ('validation_runs', 72), ('selections', 8),
                          ('label_free_files', 80), ('validation_npz', 72), ('scored_target_npz', 80)]:
        audit.check(inventory[key] == expected, 'full_output_inventory', key)
    audit.check(completion['run_count'] == 80 and completion['expected_target_runs'] == 80 and
                protocol['expected_target_runs'] == 80 and protocol['expected_validation_runs'] == 72,
                'completion_protocol_counts', 'completion')
    environment = audit_environment(audit, base, synced, protocol, args.restored_features)
    report = {'posthoc': protocol['posthoc'], 'input_directory': str(base),
              'accuracy_unit': 'percent', 'difference_unit': 'percentage points',
              'order_sd_scope': 'sample SD across ten matched seeds; macro uses equal-domain means per seed',
              'target_seeds': SEEDS, 'validation_seeds': CV_SEEDS,
              'comparison_scope': 'Original gate and original core pr_frozen: matching dataset/domain/seed 100--109 and batch64.',
              'datasets': {}, 'script_sha256': sha256(__file__)}
    validation_orders, static_cache = {}, {}
    for dataset, domains in DOMAINS.items():
        result = {'domains': {}, 'paired_domain_orders': [], 'paired_macro_orders': []}
        for target in domains:
            selection = audit_selection(audit, base, synced, dataset, target, validation_orders)
            rows = [audit_target(audit, base, synced, dataset, target, seed, selection, static_cache) for seed in SEEDS]
            domain_summary = summarize_rows(rows)
            domain_summary.update(n=rows[0]['n'], selection=selection)
            result['domains'][target] = domain_summary
            result['paired_domain_orders'].extend(rows)
        for seed in SEEDS:
            rows = [r for r in result['paired_domain_orders'] if r['seed'] == seed]
            audit.check(len(rows) == 4, 'macro_matched_domain_count', dataset + '/' + str(seed))
            result['paired_macro_orders'].append({'seed': seed,
                'accuracy': {key: float(np.mean([r['accuracy'][key] for r in rows])) for key in METHODS},
                'accepted_batches': sum(r['accepted_batches'] for r in rows),
                'total_batches': sum(r['total_batches'] for r in rows)})
        result['macro'] = summarize_rows(result['paired_macro_orders'])
        result['selection_counts'] = {
            'gate_enabled_domains': sum(d['selection']['decision']['gate_enabled'] for d in result['domains'].values()),
            'zeroshot_fallback_domains': sum(d['selection']['decision']['fallback'] == 'zeroshot' for d in result['domains'].values()),
            'source_prototype_fallback_domains': sum(d['selection']['decision']['fallback'] == 'source_prototype' for d in result['domains'].values())}
        report['datasets'][dataset] = result
    integrity = {'passed': not audit.errors, 'created_utc': datetime.now(timezone.utc).isoformat(),
                 'inventory': inventory, 'checks': dict(audit.counts), 'errors': audit.errors,
                 'warnings': audit.warnings, 'audit_script_sha256': sha256(__file__),
                 'output_manifest_sha256': sha256(base / 'output_manifest.json'),
                 'environment': environment, 'comparison_artifacts': audit.references,
                 'chronology_limit': 'Label-free/scored hash identity and code ordering are verified; hashes do not provide independently trusted execution timestamps.'}
    report['integrity_passed'] = integrity['passed']
    save_json(base / 'integrity_audit.json', integrity)
    save_json(args.report, report)
    (base / 'AUDIT.md').write_text(make_markdown(report, integrity), encoding='utf-8')
    print(json.dumps({'passed': integrity['passed'], 'errors': len(audit.errors), 'inventory': inventory,
                      'report': str(args.report)}, indent=2))
    if audit.errors:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
