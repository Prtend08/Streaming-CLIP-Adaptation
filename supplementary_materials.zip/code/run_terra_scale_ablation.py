"""Focused TerraIncognita factorial ablation using the verified feature cache.

This experiment separates two protocol choices that were confounded in the
main revision study: entropy-update count (5 versus 8) and logit-scale state
(fixed, learned but reset per batch, or learned and retained across the stream).
It also repeats the retained/reset comparison for the proposed product-weighted
reliability rule with frozen source prototypes.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import time

import numpy as np
import torch
import torch.nn.functional as F


INITIAL_LOG_SCALE = math.log(100.0)
SEEDS = list(range(100, 110))


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def sha256_array(value):
    return hashlib.sha256(value.numpy().tobytes()).hexdigest()


def prototypes(features, labels, text_weights):
    result = []
    for class_index in range(len(text_weights)):
        selected = features[labels == class_index]
        result.append(
            F.normalize(selected.mean(0), dim=0)
            if len(selected)
            else text_weights[class_index]
        )
    return torch.stack(result)


class ControlledAdapter:
    def __init__(self, text_weights, source_prototypes, *, steps, scale_mode, weighting):
        self.text_weights = text_weights.detach()
        self.source_prototypes = source_prototypes.detach()
        self.steps = int(steps)
        self.scale_mode = scale_mode
        self.weighting = weighting
        self.log_scale = torch.tensor(
            INITIAL_LOG_SCALE,
            device=text_weights.device,
            dtype=text_weights.dtype,
            requires_grad=(scale_mode != "fixed"),
        )

    @torch.no_grad()
    def reliability(self, features, probabilities):
        entropy = -(
            probabilities.clamp_min(1e-12)
            * probabilities.clamp_min(1e-12).log()
        ).sum(-1)
        confidence = (1.0 - entropy / math.log(len(self.text_weights))).clamp_min(0)
        predicted = probabilities.argmax(-1)
        consistency = F.cosine_similarity(
            features, self.source_prototypes[predicted], dim=-1
        ).clamp_min(0)
        return confidence * consistency

    def _scale(self):
        if self.scale_mode == "fixed":
            return torch.tensor(100.0, device=self.text_weights.device)
        return self.log_scale.exp()

    def predict(self, features):
        if self.scale_mode == "reset":
            with torch.no_grad():
                self.log_scale.fill_(INITIAL_LOG_SCALE)

        delta = torch.zeros_like(self.text_weights, requires_grad=True)
        parameters = [delta]
        if self.scale_mode != "fixed":
            parameters.append(self.log_scale)
        optimizer = torch.optim.Adam(parameters, lr=5e-4)

        with torch.no_grad():
            initial_scale = float(self._scale())
            initial_probabilities = (
                self._scale() * features @ self.text_weights.T
            ).softmax(-1)
            initial_entropy = float(
                -(
                    initial_probabilities.clamp_min(1e-12)
                    * initial_probabilities.clamp_min(1e-12).log()
                ).sum(-1).mean()
            )
            keep = max(1, int(0.9 * len(features)))
            if self.weighting == "uniform":
                ranking_entropy = -(
                    initial_probabilities.clamp_min(1e-12)
                    * initial_probabilities.clamp_min(1e-12).log()
                ).sum(-1)
                selected = torch.topk(ranking_entropy, keep, largest=False).indices
            else:
                selected = torch.topk(
                    self.reliability(features, initial_probabilities), keep
                ).indices

        for _ in range(self.steps):
            adapted_weights = F.normalize(self.text_weights + delta, dim=-1)
            probabilities = (
                self._scale() * features[selected] @ adapted_weights.T
            ).softmax(-1)
            entropy = -(
                probabilities.clamp_min(1e-12)
                * probabilities.clamp_min(1e-12).log()
            ).sum(-1)
            if self.weighting == "product":
                reliability = self.reliability(features[selected], probabilities)
                loss = (reliability * entropy).sum() / reliability.sum().clamp_min(1e-6)
            else:
                loss = entropy.mean()
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_([delta], 1.0)
            optimizer.step()

        with torch.no_grad():
            final_scale = float(self._scale())
            logits = self._scale() * features @ F.normalize(
                self.text_weights + delta, dim=-1
            ).T
            probabilities = logits.softmax(-1)
            final_entropy = float(
                -(
                    probabilities.clamp_min(1e-12)
                    * probabilities.clamp_min(1e-12).log()
                ).sum(-1).mean()
            )
        diagnostics = {
            "initial_scale": initial_scale,
            "final_scale": final_scale,
            "initial_entropy": initial_entropy,
            "final_entropy": final_entropy,
        }
        return logits, diagnostics


VARIANTS = {
    "entropy_fixed_s5": {"steps": 5, "scale_mode": "fixed", "weighting": "uniform"},
    "entropy_fixed_s8": {"steps": 8, "scale_mode": "fixed", "weighting": "uniform"},
    "entropy_reset_s8": {"steps": 8, "scale_mode": "reset", "weighting": "uniform"},
    "entropy_retained_s8": {"steps": 8, "scale_mode": "retained", "weighting": "uniform"},
    "pgr_frozen_reset_s8": {"steps": 8, "scale_mode": "reset", "weighting": "product"},
    "pgr_frozen_retained_s8": {"steps": 8, "scale_mode": "retained", "weighting": "product"},
}


def load_feature_cache(core_root, backbone):
    directory = core_root / "features" / "TerraIncognita" / backbone
    text_weights = torch.load(
        directory / "text_weights.pt", map_location="cpu", weights_only=True
    ).float().cuda()
    cache = {}
    for path in sorted(directory.glob("location_*.pt")):
        value = torch.load(path, map_location="cpu", weights_only=True)
        cache[path.stem] = (
            value["features"].float().cuda(),
            value["labels"].long().cuda(),
        )
    if len(cache) != 4:
        raise RuntimeError(f"Expected four TerraIncognita domains, found {sorted(cache)}")
    return text_weights, cache


def run_backbone(core_root, output_root, backbone):
    text_weights, cache = load_feature_cache(core_root, backbone)
    base = output_root / backbone
    base.mkdir(parents=True, exist_ok=True)
    for target_domain, (target_features, target_labels) in cache.items():
        source_features = torch.cat(
            [features for domain, (features, _) in cache.items() if domain != target_domain]
        )
        source_labels = torch.cat(
            [labels for domain, (_, labels) in cache.items() if domain != target_domain]
        )
        source_prototypes = prototypes(source_features, source_labels, text_weights)
        with torch.no_grad():
            zero_shot_prediction = (target_features @ text_weights.T).argmax(-1)
            zero_shot_accuracy = float(
                (zero_shot_prediction == target_labels).float().mean() * 100
            )
        for seed in SEEDS:
            order = torch.randperm(
                len(target_labels), generator=torch.Generator().manual_seed(seed)
            )
            order_hash = sha256_array(order)
            order = order.cuda()
            for variant, protocol in VARIANTS.items():
                destination = base / f"{target_domain}__{variant}__{seed}.json"
                if destination.exists():
                    continue
                torch.manual_seed(seed)
                torch.cuda.manual_seed_all(seed)
                adapter = ControlledAdapter(text_weights, source_prototypes, **protocol)
                predictions = torch.empty_like(target_labels)
                batches = []
                torch.cuda.synchronize()
                started = time.perf_counter()
                for start in range(0, len(order), 64):
                    indices = order[start : start + 64]
                    logits, diagnostics = adapter.predict(target_features[indices])
                    prediction = logits.argmax(-1)
                    predictions[indices] = prediction
                    batches.append(
                        {
                            "start": start,
                            "n": len(indices),
                            "correct": int((prediction == target_labels[indices]).sum()),
                            **diagnostics,
                        }
                    )
                torch.cuda.synchronize()
                duration = time.perf_counter() - started
                correct = int((predictions == target_labels).sum())
                np.savez_compressed(
                    destination.with_suffix(".npz"),
                    prediction=predictions.cpu().numpy(),
                    labels=target_labels.cpu().numpy(),
                    order=order.cpu().numpy(),
                )
                save_json(
                    destination,
                    {
                        "dataset": "TerraIncognita",
                        "backbone": backbone,
                        "domain": target_domain,
                        "variant": variant,
                        "protocol": protocol,
                        "seed": seed,
                        "n": len(target_labels),
                        "correct": correct,
                        "accuracy": correct / len(target_labels) * 100,
                        "zero_shot_accuracy": zero_shot_accuracy,
                        "order_sha256": order_hash,
                        "adaptation_seconds": duration,
                        "batches": batches,
                    },
                )
                print(
                    "RUN",
                    backbone,
                    target_domain,
                    variant,
                    seed,
                    round(correct / len(target_labels) * 100, 4),
                    round(batches[-1]["final_scale"], 3),
                    flush=True,
                )
        del source_features, source_labels, source_prototypes
    del cache, text_weights
    torch.cuda.empty_cache()


def summarize(output_root):
    records = []
    for path in output_root.glob("ViT-*/*.json"):
        if path.name in ("summary.json", "completion.json"):
            continue
        value = json.loads(path.read_text(encoding="utf-8"))
        records.append(value)
    summary = {"backbones": {}, "record_count": len(records)}
    for backbone in ("ViT-B-16", "ViT-L-14"):
        backbone_records = [record for record in records if record["backbone"] == backbone]
        backbone_summary = {}
        for variant in VARIANTS:
            selected = [record for record in backbone_records if record["variant"] == variant]
            per_order = []
            for seed in SEEDS:
                seed_records = [record for record in selected if record["seed"] == seed]
                if len(seed_records) == 4:
                    per_order.append(float(np.mean([record["accuracy"] for record in seed_records])))
            final_scales = [record["batches"][-1]["final_scale"] for record in selected]
            final_entropies = [
                float(np.mean([batch["final_entropy"] for batch in record["batches"]]))
                for record in selected
            ]
            backbone_summary[variant] = {
                "orders": len(per_order),
                "domain_macro_accuracy_mean": float(np.mean(per_order)),
                "domain_macro_accuracy_sample_sd": float(np.std(per_order, ddof=1)),
                "per_order_domain_macro_accuracy": per_order,
                "final_stream_scale_mean": float(np.mean(final_scales)),
                "mean_batch_final_entropy": float(np.mean(final_entropies)),
            }
        zero_shot_by_domain = {}
        for record in backbone_records:
            zero_shot_by_domain[record["domain"]] = record["zero_shot_accuracy"]
        backbone_summary["zero_shot"] = {
            "domain_macro_accuracy": float(np.mean(list(zero_shot_by_domain.values()))),
            "per_domain": zero_shot_by_domain,
        }
        summary["backbones"][backbone] = backbone_summary
    save_json(output_root / "summary.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--core-root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--only-backbone", choices=("ViT-B-16", "ViT-L-14"))
    args = parser.parse_args()
    if not torch.cuda.is_available():
        raise RuntimeError("Focused ablation requires CUDA")
    args.out.mkdir(parents=True, exist_ok=True)
    backbones = [args.only_backbone] if args.only_backbone else ["ViT-B-16", "ViT-L-14"]
    save_json(
        args.out / "environment.json",
        {
            "gpu": torch.cuda.get_device_name(),
            "torch": torch.__version__,
            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "backbones": backbones,
            "seeds": SEEDS,
            "batch_size": 64,
            "started_unix": time.time(),
        },
    )
    for backbone in backbones:
        run_backbone(args.core_root, args.out, backbone)
    summary = summarize(args.out)
    save_json(
        args.out / "completion.json",
        {
            "complete": True,
            "finished_unix": time.time(),
            "record_count": summary["record_count"],
            "expected_record_count": len(backbones) * 4 * len(SEEDS) * len(VARIANTS),
        },
    )
    print("COMPLETE", summary["record_count"], flush=True)


if __name__ == "__main__":
    main()
