"""Fresh QuickDraw prefix-holdout validation for the source-calibrated gate."""
from pathlib import Path
import csv, hashlib, json, sys, os
import numpy as np
import requests
import torch

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'quickdraw_data_independent'
OUT=Path(os.environ.get('PGR_HOLDOUT_OUT', str(ROOT/'reproduced/quickdraw_holdout')))
FEAT=Path(os.environ.get('PGR_FEATURES_ROOT', str(ROOT/'core/features')))
CLASSES=['dog','elephant','giraffe','guitar','horse','house']
sys.path.insert(0,str(ROOT/'code'))
sys.path.insert(0,str(ROOT/'code/legacy'))
from run_revision import ResidualAdapter, prototypes, save_json
from quickdraw_application import render

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
    return h.hexdigest()

def prepare():
    DATA.mkdir(parents=True,exist_ok=True)
    for name in CLASSES:
        dst=DATA/(name+'.jsonl')
        if dst.exists() and len(dst.read_text().splitlines())==500: continue
        url=f'https://storage.googleapis.com/quickdraw_dataset/full/simplified/{name}.ndjson'
        rows=[]
        with requests.get(url,stream=True,timeout=60) as resp:
            resp.raise_for_status()
            for i,line in enumerate(resp.iter_lines()):
                if not line: continue
                if i<500: continue
                v=json.loads(line)
                rows.append({'key_id':v['key_id'],'category':name,'label':CLASSES.index(name),'drawing':v['drawing']})
                if len(rows)==500: break
        if len(rows)!=500: raise RuntimeError((name,len(rows)))
        dst.write_text('\n'.join(json.dumps(x,separators=(',',':')) for x in rows)+'\n')
    save_json(DATA/'DATA_CARD.json',{
        'source':'https://github.com/googlecreativelab/quickdraw-dataset','license':'CC BY 4.0',
        'classes':CLASSES,'n_per_class':500,'selection':'records 501-1000 in source-file order, disjoint from the original first-500 prefix',
        'files':{p.name:digest(p) for p in DATA.glob('*.jsonl')}})

def load_features(path):
    z=torch.load(path,map_location='cuda',weights_only=True)
    return z['features'].cuda(),z['labels'].cuda()

def source_threshold(w,cache):
    vals=[]
    domains=list(cache)
    for held in domains:
        train=[cache[d] for d in domains if d!=held]
        mu=prototypes(torch.cat([q[0] for q in train]),torch.cat([q[1] for q in train]),w)
        x,y=cache[held]; p=(100*x@w.T).softmax(-1)
        s=ResidualAdapter(w,mu,'pr_frozen').scores(x,p)
        vals.extend(s[p.argmax(-1).eq(y)].detach().cpu().tolist())
    tau=float(np.quantile(np.asarray(vals,dtype=np.float64),.25))
    return tau,{'quantile':.25,'n_source_correct':len(vals),'threshold':tau,'source_domains':domains,'target_labels_used':False}

def main():
    torch.set_num_threads(4); prepare(); OUT.mkdir(parents=True,exist_ok=True); (OUT/'runs').mkdir(exist_ok=True)
    import open_clip
    from clip_backbone import Backbone, build_zeroshot_text_weights
    model_raw, _, preprocess = open_clip.create_model_and_transforms(
        'ViT-B-16', pretrained=os.environ.get('PGR_B16_CHECKPOINT', 'laion2b_s34b_b88k'))
    tokenizer = open_clip.get_tokenizer('ViT-B-16')
    model=Backbone(model=model_raw.to('cuda').eval(), preprocess=preprocess,
                   tokenizer=tokenizer, embed_dim=model_raw.visual.output_dim, device='cuda')
    with torch.no_grad():
        w=build_zeroshot_text_weights(model,CLASSES).float()
        records=[json.loads(line) for name in CLASSES for line in (DATA/(name+'.jsonl')).read_text().splitlines()]
        fs=[]
        for st in range(0,len(records),96):
            images=torch.stack([model.preprocess(render(r)) for r in records[st:st+96]])
            fs.append(model.encode_image(images).float())
        qx=torch.cat(fs); qy=torch.tensor([r['label'] for r in records],device='cuda')
    cache={d:load_features(FEAT/'PACS'/'ViT-B-16'/(d+'.pt')) for d in ['art_painting','cartoon','photo']}
    cache={d:(x[y<6],y[y<6]) for d,(x,y) in cache.items()}
    tau,cal=source_threshold(w,cache)
    protocol={'created':'2026-09-29','dataset':'QuickDraw','backbone':'LAION OpenCLIP ViT-B-16','batch_size':64,
      'orders':list(range(225,245)),'threshold_rule':'fixed source-correct leave-one-source-domain-out 25th percentile; NumPy linear quantile',
      'threshold':tau,'source_domains':list(cache),'target_labels_used_by_gate':False,'locked_before_holdout_results':True,
      'purpose':'independent record-prefix holdout: records 501-1000 per class, disjoint from the original first-500 prefix'}
    save_json(OUT/'protocol.json',protocol); save_json(OUT/'calibration.json',cal); save_json(DATA/'DATA_CARD.json',json.loads((DATA/'DATA_CARD.json').read_text()))
    mu=prototypes(torch.cat([v[0] for v in cache.values()]),torch.cat([v[1] for v in cache.values()]),w)
    rows=[]
    for seed in range(225,245):
        gen=torch.Generator(device='cuda').manual_seed(seed); order=torch.randperm(len(qy),generator=gen,device='cuda'); x=qx[order]; y=qy[order]
        always=ResidualAdapter(w,mu,'pr_frozen'); gate=ResidualAdapter(w,mu,'pr_frozen'); ent=ResidualAdapter(w,mu,'budget_bpt8')
        preds={m:[] for m in ['zeroshot','always_on_frozen_pgr','gated_frozen_pgr','matched_entropy']}; enabled=0; total=0
        for st in range(0,len(y),64):
            b=x[st:st+64]; p0=(100*b@w.T).softmax(-1); on=float(gate.scores(b,p0).median())>=tau; enabled+=int(on); total+=1
            preds['zeroshot'].append((100*b@w.T).argmax(-1)); preds['always_on_frozen_pgr'].append(always.predict(b).argmax(-1)); preds['gated_frozen_pgr'].append((gate.predict(b) if on else 100*b@w.T).argmax(-1)); preds['matched_entropy'].append(ent.predict(b).argmax(-1))
        acc={m:float(torch.cat(v).eq(y).float().mean().item()*100) for m,v in preds.items()}
        row={'seed':seed,**acc,'enabled_batches':enabled,'total_batches':total,'enabled_fraction':enabled/total,'threshold':tau}; rows.append(row); save_json(OUT/'runs'/f's{seed}.json',row); print('INDEPENDENT_HOLDOUT',seed,acc,'enabled',enabled,'/',total,flush=True)
    with (OUT/'summary.csv').open('w',newline='') as f: csv.DictWriter(f,fieldnames=list(rows[0])).writeheader(); csv.DictWriter(f,fieldnames=list(rows[0])).writerows(rows)
    arr={m:np.asarray([r[m] for r in rows]) for m in ['zeroshot','always_on_frozen_pgr','gated_frozen_pgr','matched_entropy']}
    summary={m:{'mean':float(v.mean()),'sample_sd':float(v.std(ddof=1))} for m,v in arr.items()}
    contrasts={m:{'mean_diff_vs_zero':float((arr[m]-arr['zeroshot']).mean()),'mean_diff_vs_always':float((arr[m]-arr['always_on_frozen_pgr']).mean())} for m in ['gated_frozen_pgr','matched_entropy']}
    save_json(OUT/'summary.json',{'protocol':protocol,'summary':summary,'contrasts':contrasts,'enabled_fraction_mean':float(np.mean([r['enabled_fraction'] for r in rows])),'rows':rows})
    print(json.dumps({'summary':summary,'contrasts':contrasts},indent=2),flush=True)

if __name__=='__main__': main()
