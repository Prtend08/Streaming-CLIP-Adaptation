# Focused TerraIncognita Scale-State Ablation

## Purpose

This post-review diagnostic separates two protocol differences that were
confounded in the main experiment: the number of per-batch entropy updates and
whether the learned scalar logit scale is retained across the target stream.
It is a mechanism diagnostic, not a replacement primary endpoint.

## Locked matrix

- Dataset: TerraIncognita, DomainBed leave-one-domain-out protocol.
- Backbones: LAION OpenCLIP ViT-B/16 and ViT-L/14.
- Target domains: location_100, location_38, location_43, and location_46.
- Orders: seeds 100--109, using the same target permutations as the main
  randomized TerraIncognita experiment.
- Batch size: 64.
- Optimizer: Adam, learning rate 5e-4.
- Selection: top 90% by low entropy for uniform-entropy variants and top 90%
  by the confidence-times-source-prototype score for PGR variants.
- Class-feature residual: reset every batch; gradient norm clipped at 1.0 in
  every factorial condition.
- Source prototypes: computed only from labeled non-target domains and frozen.
- Initial logit scale: 100 (log-scale log(100)).
- Target labels: never passed to selection, optimization, or state updates;
  labels are used only after each prediction for scoring.

## Conditions

1. `entropy_fixed_s5`: five updates; scale fixed at 100.
2. `entropy_fixed_s8`: eight updates; scale fixed at 100.
3. `entropy_reset_s8`: eight updates; scale learned within each batch and reset
   to 100 before the next batch.
4. `entropy_retained_s8`: eight updates; scale learned and retained across
   batches.
5. `pgr_frozen_reset_s8`: PGR weighting with frozen prototypes; learned scale
   reset each batch.
6. `pgr_frozen_retained_s8`: PGR weighting with frozen prototypes; learned
   scale retained across batches.

## Prespecified contrasts

- Update-count effect: `entropy_fixed_s8 - entropy_fixed_s5`.
- Within-batch scale-learning effect: `entropy_reset_s8 - entropy_fixed_s8`.
- Cross-batch scale-retention effect:
  `entropy_retained_s8 - entropy_reset_s8`.
- PGR scale-retention effect:
  `pgr_frozen_retained_s8 - pgr_frozen_reset_s8`.

Each contrast is computed on the four-domain macro accuracy for each of the ten
paired orders. Reports include the paired mean difference, sample SD, 95%
Student-t confidence interval, and two-sided paired t-test. Given the diagnostic
sample size, effect magnitude and consistency are interpreted together with the
interval rather than by a p-value alone.

## Integrity checks

The run must contain exactly 480 JSON records and 480 prediction NPZ files
(2 backbones x 4 domains x 10 orders x 6 conditions). Every JSON record stores
the order hash, per-batch accuracy count, initial/final scale, and
initial/final predictive entropy. The executable script and all outputs are
included in the supplementary archive with SHA-256 hashes.
