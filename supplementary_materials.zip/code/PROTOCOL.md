# ArtHCI44493 revision experiment protocol — locked before new result inspection

Date: 2026-09-01. All new model experiments execute on the authorized AutoDL GPU.
Historical files remain unchanged. This study extends an already inspected paper;
it is not an independent dataset-level confirmation or a preregistered study.

## Primary question and information budget
Does source-prototype-consistent reliability improve adaptation beyond an
entropy/ confidence control with the SAME 8 steps, optimizer, trainable scalar,
batch size, residual reset, clipping and checkpoint? Source statistics are explicitly
available; this is not unrestricted source-free test-time adaptation. The source
prototype classifier and source-selected static fusion are additional controls
that actually use the same labeled-source information.

## Frozen settings and sampling
- Batch size 64; Adam learning rate 0.0005; 8 steps; retained fraction 0.9;
  residual-gradient clipping 1.0; log-scale initialized to log(100).
- Settings above are inherited from historical development, NOT retroactively
  described as target-label-free selected settings.
- Original PR eta=0.3 and frozen eta=0 are both retained. The latter is a known
  historical ablation, not relabeled an independently discovered optimum.
- New paired order seeds 100–119 on PACS; 100–109 on OfficeHome/TerraIncognita.
  Fixed count; no stopping when a p-value crosses a threshold.
- Primary matrix: LAION ViT-B/16 on all three datasets; OpenAI ViT-B/16 on PACS;
  LAION ViT-L/14 on all three datasets. No target-domain selection by outcome.
- Every held-out target uses prototypes built from the OTHER domains only.
- Static fusion lambda in {0, .25, .5, .75, 1} selected by leave-one-source-domain-out
  validation. Target labels are unavailable to selection and adaptation code.
- All labels enter only source construction, source validation, or final scoring.

## Endpoints and interpretation
Primary comparisons: original PR vs budget/state-matched entropy control, and
original PR vs confidence-weighted control. Report both, effect in percentage
points, paired 95% CI, two-sided t/Wilcoxon results, and multiplicity adjustment
for families of comparisons. Dataset macro-average is calculated once per order;
domains are not treated as additional independent seeds. Domain-wise Holm family
is separately defined. Order CIs do not measure independent-population uncertainty.
Always report untouched zero-shot and source-only comparisons, including failures.

## Mechanism and streaming state
Reliability = positive prototype cosine × normalized-entropy confidence.
Compare confidence, prototype similarity, and their product on all domains:
AUROC for correctness, equal-count score bins with counts and uncertainty,
risk–coverage curves and selected pseudo-label accuracy at common coverage.
Target labels are used only AFTER scores/predictions have been produced.
PACS state ablation compares frozen prototypes with persistent/reset log-scale.
Frozen encoders do not imply prompt-token learning. Persistent optimizer state
is not claimed: Adam is re-created every batch in the historical implementation.

## Efficiency and application
Report adaptation-only GPU timing explicitly separately from image preprocessing,
encoding and end-to-end timing. Do not infer interactive response time from a
64-image throughput figure. An application demo or a benchmark risk–coverage
analysis is NOT a completed user study. Do not claim user-experience improvement.

## External methods and known corrections
Historical PromptAlign wrapper passed an empty --model-dir. Logs explicitly say
the pretrained prompt model was not loaded. The old 60.50 result is therefore an
uninitialized-prompt transfer, not the released MaPLe-initialized baseline.
Verify a released compatible checkpoint and proxy statistics before reporting a
corrected official result. Check zero-update and alignment-off controls. Preserve
old outputs as audit evidence; never relabel them as corrected runs.

## Provenance and recovery
Save per-run counts, raw accuracies, per-sample predictions, order hashes, config,
GPU/software information, code SHA-256, feature/data manifests, complete logs and
completed-run markers. Synchronize these to the local revision directory.
Never ingest historical main_results_dry.csv. Synthetic unit-test results are
separate from and prohibited in manuscript result aggregation.

## Implementation correction recorded before corrected OpenAI outcomes
The old OpenCLIP wrapper loaded OpenAI parameters with standard GELU; the loader
warned that these parameters expect QuickGELU. New official-parameter comparisons
therefore explicitly enable QuickGELU and use the distinct cache/result namespace
ViT-B-16-OpenAI-QuickGELU. Earlier mismatched-activation runs are retained for audit,
excluded from corrected tables, and are not reused as features. This correction
does not affect the LAION B/L configurations. DPE uses the same corrected activation.
