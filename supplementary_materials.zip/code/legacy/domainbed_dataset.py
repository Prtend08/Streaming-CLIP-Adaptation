"""
Generic loader for DomainBed-style datasets:
    <data_root>/<folder>/<domain>/<class_name>/*.jpg

Works for PACS, VLCS, OfficeHome, TerraIncognita, DomainNet once downloaded
via DomainBed's download script (see README.md).
"""

import os
from pathlib import Path
from typing import Callable, List, Optional, Tuple

from PIL import Image
from torch.utils.data import Dataset


class DomainFolderDataset(Dataset):
    def __init__(
        self,
        data_root: str,
        dataset_folder: str,
        domain: str,
        classes: Optional[List[str]],
        transform: Optional[Callable] = None,
    ):
        self.root = Path(data_root) / dataset_folder / domain
        if not self.root.exists():
            raise FileNotFoundError(
                f"{self.root} not found. Did you run DomainBed's download.py "
                f"and point --data_root at its output directory?"
            )

        # If classes weren't hardcoded in configs/datasets.py (e.g. DomainNet),
        # discover them from the folder structure so class indices stay stable
        # across all domains of the same dataset.
        if not classes:
            classes = sorted(
                p.name for p in self.root.iterdir() if p.is_dir()
            )
        self.classes = classes
        self.class_to_idx = {c: i for i, c in enumerate(classes)}
        self.transform = transform

        self.samples: List[Tuple[str, int]] = []
        for cls in classes:
            cls_dir = self.root / cls
            if not cls_dir.exists():
                continue
            # Stable lexical order matches the official baseline wrapper and
            # makes fixed-order protocol audits exactly reproducible.
            for fname in sorted(os.listdir(cls_dir)):
                if fname.lower().endswith((".jpg", ".jpeg", ".png", ".bmp")):
                    self.samples.append((str(cls_dir / fname), self.class_to_idx[cls]))

        if len(self.samples) == 0:
            raise RuntimeError(f"No images found under {self.root}")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        img = Image.open(path).convert("RGB")
        if self.transform is not None:
            img = self.transform(img)
        return img, label


def build_source_target_split(data_root, dataset_folder, domains, held_out_domain, classes, transform):
    """Leave-one-domain-out split used throughout the paper: `held_out_domain`
    is the unlabeled test-time target; all other domains are pooled as the
    labeled source set (used to init prototypes / linear probe / CoOp)."""
    target = DomainFolderDataset(data_root, dataset_folder, held_out_domain, classes, transform)
    source_domains = [d for d in domains if d != held_out_domain]
    source_datasets = [
        DomainFolderDataset(data_root, dataset_folder, d, classes, transform)
        for d in source_domains
    ]
    return source_datasets, target
