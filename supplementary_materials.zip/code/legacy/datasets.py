"""
Registry of benchmark datasets, their domains and class lists.

All datasets are assumed to be laid out in the standard DomainBed format:
    <data_root>/<DatasetFolderName>/<domain_name>/<class_name>/*.jpg

Reviewer #1 asks for validation beyond PACS. Reviewer #5 asks specifically for
Office-Home (65 classes) to test the "degrades on many fine-grained classes"
claim from the Discussion section. VLCS and TerraIncognita are included as
additional easy wins; DomainNet is included but flagged as optional (large).
"""

from dataclasses import dataclass
from typing import List


@dataclass
class DatasetSpec:
    name: str                # key used on the CLI
    folder: str               # folder name under data_root
    domains: List[str]        # leave-one-domain-out targets
    classes: List[str]        # class names, used to build "a photo of a {cls}" prompts
    notes: str = ""


PACS = DatasetSpec(
    name="PACS",
    folder="PACS",
    domains=["art_painting", "cartoon", "photo", "sketch"],
    classes=["dog", "elephant", "giraffe", "guitar", "horse", "house", "person"],
    notes="Original paper's only benchmark.",
)

VLCS = DatasetSpec(
    name="VLCS",
    folder="VLCS",
    domains=["Caltech101", "LabelMe", "SUN09", "VOC2007"],
    classes=["bird", "car", "chair", "dog", "person"],
    notes="Reviewer #1: smallest additional benchmark, fast to run first.",
)

OFFICE_HOME = DatasetSpec(
    name="OfficeHome",
    folder="office_home",
    domains=["Art", "Clipart", "Product", "Real_World"],
    classes=[
        "Alarm_Clock", "Backpack", "Batteries", "Bed", "Bike", "Bottle", "Bucket",
        "Calculator", "Calendar", "Candles", "Chair", "Clipboards", "Computer",
        "Couch", "Curtains", "Desk_Lamp", "Drill", "Eraser", "Exit_Sign", "Fan",
        "File_Cabinet", "Flipflops", "Flowers", "Folder", "Fork", "Glasses",
        "Hammer", "Helmet", "Kettle", "Keyboard", "Knives", "Lamp_Shade", "Laptop",
        "Marker", "Monitor", "Mop", "Mouse", "Mug", "Notebook", "Oven", "Pan",
        "Paper_Clip", "Pen", "Pencil", "Postit_Notes", "Printer", "Push_Pin",
        "Radio", "Refrigerator", "Ruler", "Scissors", "Screwdriver", "Shelf",
        "Sink", "Sneakers", "Soda", "Speaker", "Spoon", "TV", "Table",
        "Telephone", "ToothBrush", "Toys", "Trash_Can", "Webcam",
    ],  # 65 classes — matches reviewer's "65 classes" figure exactly
    notes="Reviewer #5: directly tests the many-class degradation claim.",
)

TERRA_INCOGNITA = DatasetSpec(
    name="TerraIncognita",
    folder="terra_incognita",
    domains=["location_100", "location_38", "location_43", "location_46"],
    classes=[
        "bird", "bobcat", "cat", "coyote", "dog", "empty", "opossum", "rabbit",
        "raccoon", "squirrel",
    ],
    notes="Reviewer #1: harder domain shift (camera-trap imagery), good headroom.",
)

DOMAIN_NET = DatasetSpec(
    name="DomainNet",
    folder="domain_net",
    domains=["clipart", "infograph", "painting", "quickdraw", "real", "sketch"],
    classes=[],  # 345 classes — load dynamically from folder listing at runtime
    notes="Optional / large (~500GB). Only include if compute budget allows; "
          "not required to satisfy reviewer #1's 'at least two' request.",
)

REGISTRY = {
    d.name: d for d in [PACS, VLCS, OFFICE_HOME, TERRA_INCOGNITA, DOMAIN_NET]
}


def get_dataset_spec(name: str) -> DatasetSpec:
    if name not in REGISTRY:
        raise KeyError(f"Unknown dataset '{name}'. Available: {list(REGISTRY)}")
    return REGISTRY[name]
