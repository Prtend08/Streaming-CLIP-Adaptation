"""
Backbone wrapper so switching between CLIP ViT-B/16 (original paper),
CLIP ViT-L/14, and SigLIP (reviewer #5's "generality across VLMs" request) is
a one-line config change rather than a code change.
"""

from dataclasses import dataclass
from typing import Tuple

import torch
import torch.nn.functional as F
import open_clip


# name -> (open_clip model_name, pretrained tag)
BACKBONE_REGISTRY = {
    "ViT-B-16": ("ViT-B-16", "laion2b_s34b_b88k"),      # matches original paper
    "ViT-B-16-OpenAI": ("ViT-B-16", "openai"),           # checkpoint-aligned DPE audit
    "ViT-L-14": ("ViT-L-14", "laion2b_s32b_b82k"),       # reviewer #5: larger backbone
    "ViT-B-16-SigLIP": ("ViT-B-16-SigLIP", "webli"),      # reviewer #5: different VLM family
    "EVA02-B-16": ("EVA02-B-16", "merged2b_s8b_b131k"),   # reviewer #5: alternative family
}


@dataclass
class Backbone:
    model: torch.nn.Module
    preprocess: callable
    tokenizer: callable
    embed_dim: int
    device: str

    @torch.no_grad()
    def encode_image(self, images: torch.Tensor) -> torch.Tensor:
        feats = self.model.encode_image(images.to(self.device))
        return F.normalize(feats, dim=-1)

    @torch.no_grad()
    def encode_text(self, texts) -> torch.Tensor:
        tokens = self.tokenizer(texts).to(self.device)
        feats = self.model.encode_text(tokens)
        return F.normalize(feats, dim=-1)


def load_backbone(name: str, device: str = "cuda") -> Backbone:
    if name not in BACKBONE_REGISTRY:
        raise KeyError(f"Unknown backbone '{name}'. Available: {list(BACKBONE_REGISTRY)}")
    model_name, pretrained = BACKBONE_REGISTRY[name]
    model, _, preprocess = open_clip.create_model_and_transforms(model_name, pretrained=pretrained)
    tokenizer = open_clip.get_tokenizer(model_name)
    model = model.to(device).eval()
    embed_dim = model.text_projection.shape[1] if hasattr(model, "text_projection") else model.visual.output_dim
    return Backbone(model=model, preprocess=preprocess, tokenizer=tokenizer, embed_dim=embed_dim, device=device)


def build_zeroshot_text_weights(backbone: Backbone, classnames, template="a photo of a {}.") -> torch.Tensor:
    """Returns (C, d) L2-normalized zero-shot text features, one per class."""
    prompts = [template.format(c.replace("_", " ")) for c in classnames]
    return backbone.encode_text(prompts)  # (C, d)
