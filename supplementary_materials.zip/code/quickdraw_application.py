"""Independent public sketch-input replay, not a recruited-user study."""
import argparse
import json
import os
from pathlib import Path
import sys
import subprocess
import threading
import time
import numpy as np
import requests
from PIL import Image, ImageDraw
import torch
import torch.nn.functional as F
from run_revision import ResidualAdapter,prototypes,mechanism,save_json,digest

CLASSES=['dog','elephant','giraffe','guitar','horse','house']

class PowerSamples:
    def __init__(self):self.values=[];self.stop=threading.Event()
    def __enter__(self):
        def collect():
            while not self.stop.is_set():
                try:
                    value=subprocess.check_output(['nvidia-smi','--query-gpu=power.draw','--format=csv,noheader,nounits','-i','0'],text=True,timeout=2)
                    self.values.append(float(value.strip()))
                except Exception:pass
                self.stop.wait(.2)
        self.thread=threading.Thread(target=collect,daemon=True);self.thread.start();return self
    def __exit__(self,*_):self.stop.set();self.thread.join(timeout=3)

def measure_latency(model,w,mu,records,out):
    timings={}
    # Equal unrecorded work before every variant prevents GPU clock ramp-up
    # from confounding the method that happens to be measured first.
    clock_images=torch.stack([model.preprocess(render(records[i])) for i in range(64)]).cuda()
    # Long, method-local warm-up avoids first-method clock/CPU-path bias.
    for batchsize,n_batches,warmup in [(1,192,64),(64,32,16)]:
        indices=np.random.default_rng(20260901+batchsize).choice(len(records),n_batches*batchsize,replace=False).reshape(n_batches,batchsize)
        for variant in ['zeroshot','matched_entropy','confidence_weighted','pr_ema','pr_frozen']:
            adapter=ResidualAdapter(w,mu,variant) if variant!='zeroshot' else None
            for _ in range(12):
                with torch.no_grad():warm_feature=model.encode_image(clock_images).float()
                warm_logits=adapter.predict(warm_feature) if adapter else 100*warm_feature@w.T
                _=warm_logits.argmax(-1)
            torch.cuda.synchronize()
            samples=[];power=None;baseline=None
            for j,ids in enumerate(indices):
                if j==warmup:
                    torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();baseline=torch.cuda.memory_allocated()
                    power=PowerSamples();power.__enter__()
                torch.cuda.synchronize();begin=time.perf_counter()
                images=torch.stack([model.preprocess(render(records[i])) for i in ids])
                with torch.no_grad():feature=model.encode_image(images).float()
                logits=adapter.predict(feature) if adapter else 100*feature@w.T
                prediction=logits.argmax(-1).cpu()
                torch.cuda.synchronize();elapsed=(time.perf_counter()-begin)*1000
                if j>=warmup:samples.append(elapsed)
            power.__exit__();values=power.values
            timings[f'{variant}_b{batchsize}']={'variant':variant,'batch_size':batchsize,'median_batch_ms':float(np.median(samples)),
                'p95_batch_ms':float(np.quantile(samples,.95)),'mean_batch_ms':float(np.mean(samples)),
                'throughput_images_s':1000*batchsize/float(np.mean(samples)),'n_measured_batches':len(samples),'warmup_batches':warmup,
                'peak_allocated_bytes':torch.cuda.max_memory_allocated(),'baseline_allocated_bytes':baseline,
                'incremental_peak_bytes':torch.cuda.max_memory_allocated()-baseline,'gpu_board_power_w_mean':float(np.mean(values)) if values else None,
                'gpu_board_power_n_samples':len(values),'power_scope':'nvidia-smi sampled total board draw; not CPU/system energy and not idle-subtracted',
                'scope':'after equal 12-pass GPU clock stabilization: in-memory raw strokes rendering + CPU preprocessing + transfer + CLIP encoding + adaptation + CPU prediction; excludes disk/network/UI'}
    save_json(out/'end_to_end_latency.json',timings)
    save_json(out/'hardware.json',{'gpu':torch.cuda.get_device_name(),'torch':torch.__version__,
        'nvidia_smi':subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,memory.total','--format=csv,noheader'],text=True)})

def prepare(root):
    root.mkdir(parents=True,exist_ok=True)
    for label,name in enumerate(CLASSES):
        dst=root/(name+'.jsonl')
        if dst.exists():
            assert len(dst.read_text().splitlines())==500
            continue
        url=f'https://storage.googleapis.com/quickdraw_dataset/full/simplified/{name}.ndjson'
        records=[]
        with requests.get(url,stream=True,timeout=30) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if not line:
                    continue
                value=json.loads(line)
                # Deterministic first-500 prefix, NOT selected by recognition flag or model outcome.
                records.append({'key_id':value['key_id'],'category':name,'label':label,'drawing':value['drawing']})
                if len(records)==500:
                    break
        assert len(records)==500
        dst.write_text('\n'.join(json.dumps(v,separators=(',',':')) for v in records)+'\n')
        print('QUICKDRAW_PREPARED',name,len(records),flush=True)
    save_json(root/'DATA_CARD.json',{'source':'https://github.com/googlecreativelab/quickdraw-dataset',
              'license':'CC BY 4.0','classes':CLASSES,'n_per_class':500,
              'selection':'first 500 nonempty public simplified records per category, no recognized/model-based filter',
              'limitations':'prefix convenience sample; independent dataset, not random population sample or user study',
              'files':{p.name:digest(p) for p in root.glob('*.jsonl')}})

def render(record):
    image=Image.new('RGB',(288,288),'white');draw=ImageDraw.Draw(image)
    for xs,ys,*_ in record['drawing']:
        points=[(int(x)+16,int(y)+16) for x,y in zip(xs,ys)]
        if len(points)>1:
            draw.line(points,fill='black',width=3,joint='curve')
        elif points:
            x,y=points[0];draw.ellipse((x-1,y-1,x+1,y+1),fill='black')
    return image

def run(args):
    from clip_backbone import load_backbone,build_zeroshot_text_weights
    root=args.root;data=root/'quickdraw_data';out=root/'application';out.mkdir(exist_ok=True)
    records=[json.loads(line) for name in CLASSES for line in (data/(name+'.jsonl')).read_text().splitlines()]
    model=load_backbone('ViT-B-16','cuda')
    with torch.no_grad():
        w=build_zeroshot_text_weights(model,CLASSES).float()
        fs=[]
        for start in range(0,len(records),96):
            images=torch.stack([model.preprocess(render(r)) for r in records[start:start+96]])
            fs.append(model.encode_image(images).float())
        x=torch.cat(fs)
    y=torch.tensor([r['label'] for r in records],device='cuda')
    cache=root/'core'/'features'/'PACS'/'ViT-B-16'
    sources=[torch.load(cache/(d+'.pt'),map_location='cpu',weights_only=True) for d in ['art_painting','cartoon','photo']]
    sx=torch.cat([v['features'][v['labels']<6] for v in sources]).cuda()
    sy=torch.cat([v['labels'][v['labels']<6] for v in sources]).cuda()
    mu=prototypes(sx,sy,w)
    mechanism(x,y,w,mu,out/'reliability')
    static={}
    for name,ww in [('zeroshot',w),('source_prototype',mu)]:
        pred=(x@ww.T).argmax(-1)
        static[name]={'accuracy':float((pred==y).float().mean()*100),'n':len(y),'correct':int((pred==y).sum())}
    save_json(out/'static.json',static)
    for seed in range(200,205):
        order=torch.randperm(len(y),generator=torch.Generator().manual_seed(seed)).cuda()
        for batchsize in [1,64]:
            for variant in ['matched_entropy','confidence_weighted','pr_ema','pr_frozen']:
                dest=out/f'{variant}_b{batchsize}_s{seed}.json'
                if dest.exists():continue
                adapter=ResidualAdapter(w,mu,variant);predictions=torch.empty_like(y)
                torch.cuda.synchronize();start=time.perf_counter()
                for offset in range(0,len(order),batchsize):
                    idx=order[offset:offset+batchsize]
                    predictions[idx]=adapter.predict(x[idx]).argmax(-1)
                torch.cuda.synchronize();seconds=time.perf_counter()-start
                correct=int((predictions==y).sum())
                save_json(dest,{'variant':variant,'seed':seed,'batch_size':batchsize,'n':len(y),'correct':correct,
                          'accuracy':100*correct/len(y),'adaptation_seconds':seconds,'scope':'cached-feature adaptation'})
                np.savez_compressed(dest.with_suffix('.npz'),predictions=predictions.cpu().numpy(),labels=y.cpu().numpy(),order=order.cpu().numpy())
                print('APPLICATION',variant,batchsize,seed,correct/len(y)*100,seconds,flush=True)
    # Release feature caches before separately measuring end-to-end inference memory.
    adapter=None;predictions=None;order=None
    del x,y,sx,sy,sources,fs
    torch.cuda.empty_cache()
    measure_latency(model,w,mu,records,out)
    save_json(out/'completion.json',{'complete':True,'n':len(records),'classes':CLASSES,'user_study':False})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepare-only',action='store_true');p.add_argument('--root',type=Path,required=True)
    p.add_argument('--legacy-code',default='/root/autodl-tmp/project/supplement_camera_ready_stage/code');args=p.parse_args()
    sys.path.insert(0,args.legacy_code);torch.set_num_threads(4)
    prepare(args.root/'quickdraw_data')
    if not args.prepare_only:
        if not torch.cuda.is_available():raise RuntimeError('GPU required')
        run(args)
