"""Verify an extracted supplementary archive without importing model libraries."""
from pathlib import Path
import argparse
import hashlib
import json


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = p.parse_args()
    root = args.root.resolve()
    manifest = json.loads((root / 'SHA256_MANIFEST.json').read_text(encoding='utf-8'))
    errors = []
    for name, expected in manifest.items():
        path = (root / name).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            errors.append({'file': name, 'reason': 'missing or unsafe path'})
            continue
        h = hashlib.sha256()
        with path.open('rb') as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b''):
                h.update(chunk)
        if h.hexdigest() != expected:
            errors.append({'file': name, 'reason': 'SHA256 mismatch'})
    print(json.dumps({'passed': not errors, 'files_checked': len(manifest), 'errors': errors}, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
