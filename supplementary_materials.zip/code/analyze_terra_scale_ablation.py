"""Aggregate the focused Terra scale-state experiment with paired effects."""
import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np


SEEDS = list(range(100, 110))
VARIANTS = (
    "entropy_fixed_s5",
    "entropy_fixed_s8",
    "entropy_reset_s8",
    "entropy_retained_s8",
    "pgr_frozen_reset_s8",
    "pgr_frozen_retained_s8",
)
COMPARISONS = (
    ("entropy_fixed_s8", "entropy_fixed_s5", "three additional fixed-scale steps"),
    ("entropy_reset_s8", "entropy_fixed_s8", "within-batch scale learning"),
    ("entropy_retained_s8", "entropy_reset_s8", "cross-batch scale retention"),
    ("pgr_frozen_retained_s8", "pgr_frozen_reset_s8", "PGR cross-batch scale retention"),
)


def _beta_continued_fraction(a, b, x):
    maximum_iterations = 200
    epsilon = 3e-14
    tiny = 1e-300
    qab = a + b
    qap = a + 1.0
    qam = a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < tiny:
        d = tiny
    d = 1.0 / d
    value = d
    for iteration in range(1, maximum_iterations + 1):
        m2 = 2 * iteration
        aa = iteration * (b - iteration) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + aa / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        value *= d * c
        aa = -(a + iteration) * (qab + iteration) * x / (
            (a + m2) * (qap + m2)
        )
        d = 1.0 + aa * d
        if abs(d) < tiny:
            d = tiny
        c = 1.0 + aa / c
        if abs(c) < tiny:
            c = tiny
        d = 1.0 / d
        delta = d * c
        value *= delta
        if abs(delta - 1.0) < epsilon:
            return value
    raise RuntimeError("Incomplete-beta continued fraction did not converge")


def regularized_beta(x, a, b):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    factor = math.exp(
        math.lgamma(a + b)
        - math.lgamma(a)
        - math.lgamma(b)
        + a * math.log(x)
        + b * math.log1p(-x)
    )
    if x < (a + 1.0) / (a + b + 2.0):
        return factor * _beta_continued_fraction(a, b, x) / a
    return 1.0 - factor * _beta_continued_fraction(b, a, 1.0 - x) / b


def paired_t_p_two_sided(difference):
    difference = np.asarray(difference, dtype=float)
    sd = difference.std(ddof=1)
    if sd == 0:
        return 1.0 if difference.mean() == 0 else 0.0
    df = len(difference) - 1
    t_value = abs(difference.mean() / (sd / math.sqrt(len(difference))))
    return regularized_beta(df / (df + t_value * t_value), df / 2.0, 0.5)


def save_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--out-json", type=Path, required=True)
    parser.add_argument("--out-csv", type=Path, required=True)
    args = parser.parse_args()
    completion = json.loads((args.input / "completion.json").read_text(encoding="utf-8"))
    records = []
    for path in args.input.glob("ViT-*/*.json"):
        value = json.loads(path.read_text(encoding="utf-8"))
        if "variant" in value:
            records.append(value)
    if len(records) != 480:
        raise RuntimeError(f"Expected 480 completed records, found {len(records)}")
    if not completion.get("complete"):
        raise RuntimeError("Remote completion marker is not true")

    report = {"record_count": len(records), "backbones": {}}
    csv_rows = []
    for backbone in ("ViT-B-16", "ViT-L-14"):
        selected_backbone = [record for record in records if record["backbone"] == backbone]
        per_order = {}
        summaries = {}
        for variant in VARIANTS:
            values = []
            selected_variant = [record for record in selected_backbone if record["variant"] == variant]
            for seed in SEEDS:
                selected_seed = [record for record in selected_variant if record["seed"] == seed]
                if len(selected_seed) != 4:
                    raise RuntimeError((backbone, variant, seed, len(selected_seed)))
                values.append(float(np.mean([record["accuracy"] for record in selected_seed])))
            values = np.asarray(values)
            per_order[variant] = values
            final_scales = np.asarray(
                [record["batches"][-1]["final_scale"] for record in selected_variant]
            )
            summaries[variant] = {
                "mean_accuracy": float(values.mean()),
                "sample_sd": float(values.std(ddof=1)),
                "per_order": values.tolist(),
                "final_stream_scale_mean": float(final_scales.mean()),
                "final_stream_scale_min": float(final_scales.min()),
                "final_stream_scale_max": float(final_scales.max()),
            }
            csv_rows.append(
                {
                    "backbone": backbone,
                    "kind": "variant",
                    "name": variant,
                    "mean_accuracy": values.mean(),
                    "sample_sd": values.std(ddof=1),
                    "delta": "",
                    "ci_low": "",
                    "ci_high": "",
                    "p_value": "",
                    "final_scale_mean": final_scales.mean(),
                }
            )

        comparisons = {}
        for left, right, label in COMPARISONS:
            difference = per_order[left] - per_order[right]
            sem = difference.std(ddof=1) / math.sqrt(len(difference))
            # df=9 for the locked ten paired orders.
            half_width = 2.2621571627409915 * sem
            interval = (difference.mean() - half_width, difference.mean() + half_width)
            p_value = paired_t_p_two_sided(difference)
            comparisons[label] = {
                "left": left,
                "right": right,
                "mean_delta": float(difference.mean()),
                "sample_sd_delta": float(difference.std(ddof=1)),
                "ci_low": float(interval[0]),
                "ci_high": float(interval[1]),
                "paired_t_p_two_sided": float(p_value),
                "per_order_delta": difference.tolist(),
            }
            csv_rows.append(
                {
                    "backbone": backbone,
                    "kind": "paired_comparison",
                    "name": label,
                    "mean_accuracy": "",
                    "sample_sd": difference.std(ddof=1),
                    "delta": difference.mean(),
                    "ci_low": interval[0],
                    "ci_high": interval[1],
                    "p_value": p_value,
                    "final_scale_mean": "",
                }
            )
        report["backbones"][backbone] = {
            "variants": summaries,
            "comparisons": comparisons,
        }

    args.out_json.parent.mkdir(parents=True, exist_ok=True)
    save_json(args.out_json, report)
    with args.out_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(csv_rows[0]))
        writer.writeheader()
        writer.writerows(csv_rows)
    print("TERRA_SCALE_REPORT", args.out_json, args.out_csv, len(records))


if __name__ == "__main__":
    main()
