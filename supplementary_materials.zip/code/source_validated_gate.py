"""Post-hoc source-validated policy; preserves the original 8-step PGR adapter.

This is a NEW post-hoc experiment, not a repair or replacement of earlier gate
results. Selection sees only the three permitted source domains. Nested LOSO
validation and the full-source deployment threshold are saved before the true
target tensor is loaded. No target outcome is used to select the policy.

Example (both datasets; 80 target runs):
  python source_validated_gate.py --features-root /path/to/core/features \
    --adapter-script /path/to/run_revision.py --out /path/to/new_output
Use --dataset OfficeHome or --dataset TerraIncognita for 40 target runs.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np

# Torch is imported in main, allowing a pure-Python selector self-check without
# GPU dependencies. Empirical execution always requires CUDA.
torch = None
ResidualAdapter = None
prototypes = None

DOMAINS = {
    'OfficeHome': ['Art', 'Clipart', 'Product', 'Real_World'],
    'TerraIncognita': ['location_100', 'location_38', 'location_43', 'location_46'],
}
BACKBONE = 'ViT-B-16'
VALIDATION_SEEDS = (7000, 7001, 7002)
TARGET_SEEDS = tuple(range(100, 110))
BATCH_SIZE = 64
QUANTILE = 0.25
POSTHOC = ('New post-hoc source-validated policy after earlier benchmark and gate '
           'outcomes were known; not preregistered, independent confirmation, or '
           'a no-harm guarantee. Earlier results remain unchanged.')


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    tmp.replace(path)


def save_npz(path, arrays):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    with tmp.open('wb') as handle:
        np.savez_compressed(handle, **arrays)
    tmp.replace(path)


def artifact(path, relative_to=None):
    path = Path(path)
    return {'path': str(path.relative_to(relative_to) if relative_to else path),
            'sha256': sha256(path), 'bytes': path.stat().st_size}


def load_adapter(path):
    global ResidualAdapter, prototypes
    spec = importlib.util.spec_from_file_location('source_policy_original_adapter', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    ResidualAdapter, prototypes = module.ResidualAdapter, module.prototypes


def load_source(path, classes):
    saved = torch.load(path, map_location='cpu', weights_only=True)
    x, y = saved['features'].float(), saved['labels'].long()
    assert x.ndim == 2 and len(x) == len(y) and len(x) > 0
    assert torch.isfinite(x).all() and int(y.min()) >= 0 and int(y.max()) < classes
    return x.cuda(), y.cuda()


def source_bank(source, w):
    assert source
    names = sorted(source)
    return prototypes(torch.cat([source[d][0] for d in names]),
                      torch.cat([source[d][1] for d in names]), w)


def calibrate_from_sources(source, w, out_dir):
    """LOSO source-correct q=.25. True target is absent from this interface."""
    assert len(source) >= 2
    records = {k: [] for k in ['score', 'prediction', 'labels', 'held_domain', 'sample_index']}
    fold_info = []
    with torch.no_grad():
        for held in sorted(source):
            train = {d: v for d, v in source.items() if d != held}
            mu = source_bank(train, w)
            x, y = source[held]
            p = (100. * x @ w.T).softmax(-1)
            score = ResidualAdapter(w, mu, 'pr_frozen').scores(x, p)
            pred = p.argmax(-1)
            records['score'].append(score.cpu().numpy())
            records['prediction'].append(pred.cpu().numpy())
            records['labels'].append(y.cpu().numpy())
            records['held_domain'].append(np.full(len(y), held))
            records['sample_index'].append(np.arange(len(y), dtype=np.int64))
            fold_info.append({'held_source': held, 'prototype_sources': sorted(train),
                              'n': len(y), 'correct': int((pred == y).sum())})
    arrays = {k: np.concatenate(v) for k, v in records.items()}
    correct = arrays['prediction'] == arrays['labels']
    values = arrays['score'][correct].astype(np.float64)
    # Empty source-correct sets disable the candidate gate; never use a
    # target-derived replacement threshold or a non-JSON infinity sentinel.
    tau = float(np.quantile(values, QUANTILE)) if len(values) else None
    score_path = out_dir / 'calibration_scores.npz'
    save_npz(score_path, {**arrays, 'correct': correct.astype(np.int8)})
    result = {'quantile': QUANTILE, 'quantile_method': 'numpy linear',
              'threshold': tau, 'usable': tau is not None,
              'n_source_correct': int(len(values)), 'source_domains': sorted(source),
              'folds': fold_info, 'target_labels_used': False,
              'scores': artifact(score_path, out_dir)}
    save_json(out_dir / 'calibration.json', result)
    return tau, result


def label_free_stream(x, w, mu, seed, tau, execute_gate=True):
    """Produces all paths. No label argument; no target correctness access."""
    n = len(x)
    order_cpu = torch.randperm(n, generator=torch.Generator().manual_seed(seed))
    order = order_cpu.cuda()
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    model = ResidualAdapter(w, mu, 'pr_frozen')
    assert model.steps == 8 and model.eta == 0
    preds = {m: torch.full((n,), -1, dtype=torch.long, device=x.device)
             for m in ['zeroshot', 'source_prototype', 'gate_zeroshot', 'gate_source_prototype']}
    sample_scores = torch.empty(n, dtype=torch.float32, device=x.device)
    gates, passes, batch_scores, before_values, after_values, batches = [], [], [], [], [], []
    for j, start in enumerate(range(0, n, BATCH_SIZE)):
        idx = order[start:start+BATCH_SIZE]
        batch = x[idx]
        with torch.no_grad():
            zero_logits = 100. * batch @ w.T
            p = zero_logits.softmax(-1)
            scores = model.scores(batch, p)
            median = float(scores.median())
            zs = zero_logits.argmax(-1)
            sp = (100. * batch @ mu.T).argmax(-1)
        score_pass = bool(tau is not None and median >= tau)
        on = bool(execute_gate and score_pass)
        before = float(model.scale.detach())
        if on:
            adapted = model.predict(batch).argmax(-1).detach()
            gz, gs = adapted, adapted
        else:
            gz, gs = zs, sp
        after = float(model.scale.detach())
        assert on or before == after
        preds['zeroshot'][idx], preds['source_prototype'][idx] = zs, sp
        preds['gate_zeroshot'][idx], preds['gate_source_prototype'][idx] = gz, gs
        sample_scores[idx] = scores
        gates.append(on)
        passes.append(score_pass)
        batch_scores.append(median)
        before_values.append(before)
        after_values.append(after)
        batches.append({'batch': j, 'start': start, 'n': len(idx),
                        'sample_indices': idx.cpu().tolist(), 'threshold': tau,
                        'batch_median_score': median, 'score_pass': score_pass,
                        'gate_enabled': on, 'policy_gate_allowed': bool(execute_gate),
                        'scale_before': before, 'scale_after': after,
                        'state_action': 'adapt_reset_residual_optimizer_retain_scale' if on else 'preserve_state',
                        'prototype_change_l2': 0.0,
                        'predictions_committed_before_next_batch': True})
    arrays = {m + '_prediction': v.cpu().numpy() for m, v in preds.items()}
    assert all(np.all(v >= 0) for v in arrays.values())
    arrays.update(order=order_cpu.numpy(), gate=np.asarray(gates, dtype=np.int8),
                  score_pass=np.asarray(passes, dtype=np.int8),
                  sample_score=sample_scores.cpu().numpy(), batch_score=np.asarray(batch_scores),
                  scale_before=np.asarray(before_values), scale_after=np.asarray(after_values))
    return arrays, batches


def score_completed_predictions(arrays, labels, keys):
    """The only prediction-accuracy scorer. Called after all predictions exist."""
    labels = np.asarray(labels, dtype=np.int64)
    return {key: {'n': len(labels), 'correct': int(np.sum(arrays[key] == labels)),
                  'accuracy': float(np.mean(arrays[key] == labels) * 100)} for key in keys}


def conservative_decision(folds):
    """Source-only rule, using integer correct counts to preserve exact ties."""
    assert len(folds) == 3
    source_deltas = []
    for f in folds:
        assert len(f['orders']) == 3
        changes = [r['source_prototype_prediction']['correct'] -
                   r['zeroshot_prediction']['correct'] for r in f['orders']]
        source_deltas.append(sum(changes) / (3 * f['n']) * 100.)
    use_source = all(d >= 0 for d in source_deltas) and sum(source_deltas) > 0
    fallback = 'source_prototype' if use_source else 'zeroshot'
    gate_key = 'gate_' + fallback + '_prediction'
    fallback_key = fallback + '_prediction'
    gate_deltas = []
    for f in folds:
        changes = [r[gate_key]['correct'] - r[fallback_key]['correct'] for r in f['orders']]
        gate_deltas.append(sum(changes) / (3 * f['n']) * 100.)
    allow_gate = all(d >= 0 for d in gate_deltas) and sum(gate_deltas) > 0
    return {'fallback': fallback, 'gate_enabled': bool(allow_gate),
            'source_prototype_minus_zeroshot_per_source_pp': source_deltas,
            'source_prototype_minus_zeroshot_macro_pp': float(np.mean(source_deltas)),
            'gate_minus_selected_fallback_per_source_pp': gate_deltas,
            'gate_minus_selected_fallback_macro_pp': float(np.mean(gate_deltas)),
            'fallback_rule_passed': bool(use_source), 'gate_rule_passed': bool(allow_gate),
            'tie_rule': 'exact ties retain zero-shot fallback / disable gate',
            'source_order': [f['held_source'] for f in folds]}


def select_policy(source, w, out_dir):
    """Only permitted SOURCE (features, labels) pairs enter this selector."""
    assert len(source) == 3
    fold_summaries = []
    for held in sorted(source):
        fold_dir = out_dir / 'validation' / held
        train = {d: v for d, v in source.items() if d != held}
        assert len(train) == 2 and held not in train
        mu = source_bank(train, w)
        tau, calibration = calibrate_from_sources(train, w, fold_dir / 'inner_calibration')
        x, labels = source[held]
        orders = []
        for seed in VALIDATION_SEEDS:
            arrays, batches = label_free_stream(x, w, mu, seed, tau, execute_gate=True)
            # Held source labels enter only after that validation stream ends.
            keys = [k for k in arrays if k.endswith('_prediction')]
            metrics = score_completed_predictions(arrays, labels.cpu().numpy(), keys)
            pred_path = fold_dir / f'validation_{seed}.npz'
            save_npz(pred_path, {**arrays, 'labels': labels.cpu().numpy()})
            record = {'complete': True, 'held_source': held, 'seed': seed, 'n': len(labels),
                      'prototype_sources': sorted(train), 'threshold': tau,
                      'metrics': metrics, 'accepted_batches': int(arrays['gate'].sum()),
                      'predictions': artifact(pred_path, out_dir), 'batches': batches,
                      'order_sha256': hashlib.sha256(arrays['order'].tobytes()).hexdigest()}
            save_json(fold_dir / f'validation_{seed}.json', record)
            orders.append({'seed': seed, **metrics})
            print('SOURCE_VALIDATION', held, seed, {k:round(v['accuracy'], 4) for k,v in metrics.items()}, flush=True)
        fold_summaries.append({'held_source': held, 'n': len(labels),
                               'prototype_sources': sorted(train), 'inner_threshold': tau,
                               'orders': orders})
    decision = conservative_decision(fold_summaries)
    # Deployment tau is calibrated from permitted sources only. It is frozen
    # together with the policy even when selection disables adaptation.
    target_tau, calibration = calibrate_from_sources(source, w, out_dir / 'deployment_calibration')
    if target_tau is None:
        decision['gate_enabled'] = False
        decision['no_source_correct_calibration_disables_gate'] = True
    manifest = {'posthoc': POSTHOC, 'source_domains': sorted(source),
                'validation_seeds': list(VALIDATION_SEEDS), 'folds': fold_summaries,
                'decision': decision, 'deployment_threshold': target_tau,
                'target_labels_used_for_selection': False,
                'source_score_bank_shift': 'inner calibration uses one-source banks, held-source validation uses two, final deployment uses three',
                'frozen_at_unix': time.time()}
    save_json(out_dir / 'selection_manifest.json', manifest)
    return manifest, source_bank(source, w)


def run_dataset(features_root, dataset, out):
    directory = features_root / dataset / BACKBONE
    w = torch.load(directory / 'text_weights.pt', map_location='cuda', weights_only=True).float().detach()
    assert w.ndim == 2 and torch.isfinite(w).all()
    for target in DOMAINS[dataset]:
        source = {d: load_source(directory / (d + '.pt'), len(w))
                  for d in DOMAINS[dataset] if d != target}
        assert target not in source
        selection_dir = out / 'selection' / dataset / target
        frozen, mu = select_policy(source, w, selection_dir)
        selection_path = selection_dir / 'selection_manifest.json'
        selection_sha = sha256(selection_path)
        save_json(selection_dir / 'FROZEN_BEFORE_TARGET.json', {
            'selection_sha256': selection_sha, 'frozen_before_target_tensor_load': True,
            'unix': time.time(), 'target': target})
        del source
        torch.cuda.empty_cache()
        # The true target tensor is first loaded only after policy/calibration
        # are frozen on disk. Its labels are never passed to label_free_stream.
        saved = torch.load(directory / (target + '.pt'), map_location='cpu', weights_only=True)
        x = saved['features'].float().cuda()
        assert x.ndim == 2 and x.shape[1] == w.shape[1] and torch.isfinite(x).all()
        decision, tau = frozen['decision'], frozen['deployment_threshold']
        for seed in TARGET_SEEDS:
            started = time.time()
            arrays, batches = label_free_stream(x, w, mu, seed, tau, decision['gate_enabled'])
            selected_key = ('gate_' if decision['gate_enabled'] else '') + decision['fallback'] + '_prediction'
            arrays['prediction'] = arrays[selected_key].copy()
            # Commit the label-free selected/static predictions before scoring.
            stem = f'{target}__source_validated__{seed}'
            dest = out / 'runs' / dataset / BACKBONE / stem
            blind_keys = ['prediction', 'zeroshot_prediction', 'source_prototype_prediction',
                          'order', 'gate', 'score_pass', 'sample_score', 'batch_score',
                          'scale_before', 'scale_after']
            pred_path = dest.with_suffix('.label_free.npz')
            save_npz(pred_path, {k: arrays[k] for k in blind_keys})
            labels = saved['labels'].long().numpy()  # first target-label use
            assert len(labels) == len(x) and labels.min() >= 0 and labels.max() < len(w)
            metrics = score_completed_predictions(arrays, labels,
                                                  ['prediction', 'zeroshot_prediction', 'source_prototype_prediction'])
            npz = dest.with_suffix('.npz')
            save_npz(npz, {**{k: arrays[k] for k in blind_keys}, 'labels': labels})
            record = {'complete': True, 'dataset': dataset, 'backbone': BACKBONE,
                      'domain': target, 'seed': seed, 'variant': 'posthoc_source_validated_gate',
                      'posthoc': POSTHOC, 'n': len(labels), **metrics['prediction'],
                      'metrics': metrics, 'fallback': decision['fallback'],
                      'policy_gate_enabled': decision['gate_enabled'], 'threshold': tau,
                      'enabled_batches': int(arrays['gate'].sum()), 'total_batches': len(batches),
                      'enabled_fraction': float(arrays['gate'].mean()),
                      'prediction_file': str(npz.relative_to(out)), 'prediction_sha256': sha256(npz),
                      'label_free_prediction_file': str(pred_path.relative_to(out)),
                      'label_free_prediction_sha256': sha256(pred_path),
                      'order_sha256': hashlib.sha256(arrays['order'].tobytes()).hexdigest(),
                      'selection_file': str(selection_path.relative_to(out)),
                      'selection_sha256': selection_sha, 'target_labels_used_for_policy': False,
                      'elapsed_seconds': time.time() - started, 'batches': batches}
            assert sha256(selection_path) == selection_sha
            save_json(dest.with_suffix('.json'), record)
            print('TARGET_COMPLETE', dataset, target, seed, round(record['accuracy'], 4),
                  decision['fallback'], decision['gate_enabled'], flush=True)
        del saved, x, mu
        torch.cuda.empty_cache()


def self_check():
    """Synthetic policy logic only; no model outputs or result files are made."""
    def folds(z, source, gz, gs):
        return [{'held_source': f'source_{i}', 'n': 10,
                 'orders': [{k: {'correct': value[i]} for k, value in [
                     ('zeroshot_prediction', z), ('source_prototype_prediction', source),
                     ('gate_zeroshot_prediction', gz), ('gate_source_prototype_prediction', gs)]}
                            for _ in VALIDATION_SEEDS]} for i in range(3)]
    equal = conservative_decision(folds([5]*3, [5]*3, [5]*3, [5]*3))
    assert equal['fallback'] == 'zeroshot' and not equal['gate_enabled']
    harm = conservative_decision(folds([5]*3, [6,6,4], [7,7,4], [7,7,7]))
    assert harm['fallback'] == 'zeroshot' and not harm['gate_enabled']
    success = conservative_decision(folds([5]*3, [6,5,5], [7]*3, [7,5,5]))
    assert success['fallback'] == 'source_prototype' and success['gate_enabled']
    static = conservative_decision(folds([5]*3, [6]*3, [7]*3, [6]*3))
    assert static['fallback'] == 'source_prototype' and not static['gate_enabled']
    import inspect
    assert list(inspect.signature(select_policy).parameters) == ['source', 'w', 'out_dir']
    assert 'labels' not in inspect.signature(label_free_stream).parameters
    print('SYNTHETIC_INTERFACE_LOGIC_CHECK_PASS; no empirical results or files created.')


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--features-root', type=Path, help='Directory containing Dataset/ViT-B-16/*.pt')
    ap.add_argument('--adapter-script', type=Path, help='Unmodified original run_revision.py')
    ap.add_argument('--out', type=Path, help='New empty directory; earlier outputs are never overwritten')
    ap.add_argument('--dataset', choices=list(DOMAINS), nargs='+', default=list(DOMAINS))
    ap.add_argument('--self-check', action='store_true', help='Synthetic interface/decision checks only; no results written')
    args = ap.parse_args()
    if args.self_check:
        self_check()
        return
    if not all([args.features_root, args.adapter_script, args.out]):
        ap.error('--features-root, --adapter-script, and --out are required for empirical execution')
    args.dataset = list(dict.fromkeys(args.dataset))
    global torch
    import torch as imported_torch
    torch = imported_torch
    if not torch.cuda.is_available():
        raise RuntimeError('Empirical execution requires the authorized CUDA GPU')
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    if args.out.exists() and any(args.out.iterdir()):
        raise FileExistsError('Output directory must be empty; use a new versioned namespace')
    args.out.mkdir(parents=True, exist_ok=True)
    load_adapter(args.adapter_script.resolve())
    inputs = {}
    for dataset in args.dataset:
        d = args.features_root / dataset / BACKBONE
        for name in DOMAINS[dataset] + ['text_weights']:
            path = d / (name + '.pt')
            inputs[str(path.resolve())] = artifact(path)
    expected = 4 * len(TARGET_SEEDS) * len(args.dataset)
    protocol = {'posthoc': POSTHOC, 'datasets': args.dataset, 'backbone': BACKBONE,
                'validation_seeds': list(VALIDATION_SEEDS), 'target_seeds': list(TARGET_SEEDS),
                'quantile': QUANTILE, 'batch_size': BATCH_SIZE,
                'adapter': 'original unmodified ResidualAdapter(pr_frozen), eight steps',
                'nested_validation': 'outer held source uses other two sources for prototypes; inner tau uses LOSO across those two sources',
                'fallback_rule': 'source prototype iff every held-source delta vs ZS >= 0 and equal-domain macro > 0; otherwise ZS',
                'gate_rule': 'gate iff every held-source three-order mean delta vs selected fallback >= 0 and equal-domain macro > 0; otherwise static fallback',
                'ties': 'zero-shot fallback / gate disabled',
                'target_labels_used_for_policy': False, 'expected_target_runs': expected,
                'expected_validation_runs': 4 * 3 * 3 * len(args.dataset),
                'created_unix': time.time()}
    save_json(args.out / 'protocol.json', protocol)
    save_json(args.out / 'environment.json', {
        'captured_before_execution': True, 'unix': time.time(), 'python': sys.version,
        'platform': platform.platform(), 'torch': torch.__version__, 'cuda': torch.version.cuda,
        'gpu': torch.cuda.get_device_name(), 'num_threads': torch.get_num_threads(),
        'matmul_allow_tf32': torch.backends.cuda.matmul.allow_tf32,
        'cudnn_allow_tf32': torch.backends.cudnn.allow_tf32,
        'cudnn_benchmark': torch.backends.cudnn.benchmark, 'argv': sys.argv,
        'scripts': {'policy': artifact(Path(__file__).resolve()),
                    'original_adapter': artifact(args.adapter_script.resolve())},
        'input_tensors': inputs, 'protocol_sha256': sha256(args.out / 'protocol.json')})
    try:
        for dataset in args.dataset:
            run_dataset(args.features_root, dataset, args.out)
        runs = sorted((args.out / 'runs').rglob('*.json'))
        assert len(runs) == expected
        output_manifest = {str(p.relative_to(args.out)): {'sha256': sha256(p), 'bytes': p.stat().st_size}
                           for p in sorted(args.out.rglob('*')) if p.is_file()}
        save_json(args.out / 'output_manifest.json', output_manifest)
        save_json(args.out / 'completion.json', {'complete': True, 'expected_target_runs': expected,
                  'run_count': len(runs), 'finished_at': time.time(), 'posthoc': POSTHOC,
                  'output_manifest_sha256': sha256(args.out / 'output_manifest.json')})
    except Exception as exc:
        save_json(args.out / 'failure.json', {'complete': False, 'exception_type': type(exc).__name__,
                  'message': str(exc), 'unix': time.time()})
        raise


if __name__ == '__main__':
    main()
