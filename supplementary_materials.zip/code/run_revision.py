"""GPU-only, resumable revision study; no fabricated/dry-run result path."""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sys
import time
import traceback

import numpy as np
import torch
import torch.nn.functional as F


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')
    tmp.replace(path)


def prototypes(x, y, w):
    result = []
    for c in range(len(w)):
        selected = x[y == c]
        result.append(F.normalize(selected.mean(0), dim=0) if len(selected) else w[c])
    return torch.stack(result)


class ResidualAdapter:
    """Labels are deliberately absent from the adaptation interface."""
    def __init__(self, w, mu, variant):
        self.w, self.mu = w.detach(), mu.clone().detach()
        self.variant = variant
        self.scale = torch.tensor(4.6052, device=w.device, requires_grad=True)
        self.steps = 5 if variant == 'legacy_bpt5' else 8
        self.fixed_scale = variant in ('legacy_bpt5', 'budget_bpt8')
        self.eta = .3 if variant == 'pr_ema' else 0.
        self.reset_scale = variant == 'pr_frozen_reset_scale'
        self.score_mode = ('product' if variant.startswith('pr_') else
                           'prototype' if variant == 'prototype_weighted' else 'confidence')
        self.weighted = variant not in ('legacy_bpt5', 'budget_bpt8', 'matched_entropy', 'source_fusion_tta')

    @torch.no_grad()
    def scores(self, x, probs):
        entropy = -(probs.clamp_min(1e-12) * probs.clamp_min(1e-12).log()).sum(-1)
        conf = (1 - entropy / math.log(len(self.w))).clamp_min(0)
        sim = F.cosine_similarity(x, self.mu[probs.argmax(-1)], dim=-1).clamp_min(0)
        return conf if self.score_mode == 'confidence' else sim if self.score_mode == 'prototype' else sim * conf

    def predict(self, x):
        if self.reset_scale:
            with torch.no_grad():
                self.scale.fill_(4.6052)
        delta = torch.zeros_like(self.w, requires_grad=True)
        params = [delta] if self.fixed_scale else [delta, self.scale]
        optimizer = torch.optim.Adam(params, lr=.0005)
        with torch.no_grad():
            scale = 100. if self.fixed_scale else self.scale.exp()
            p = (scale * x @ self.w.T).softmax(-1)
            keep = max(1, int(.9 * len(x)))
            # Preserve legacy low-entropy ranking including its direction.
            if self.variant in ('legacy_bpt5', 'budget_bpt8'):
                entropy = -(p.clamp_min(1e-12) * p.clamp_min(1e-12).log()).sum(-1)
                idx = torch.topk(entropy, keep, largest=False).indices
            else:
                idx = torch.topk(self.scores(x, p), keep).indices
        for _ in range(self.steps):
            weights = F.normalize(self.w + delta, dim=-1)
            scale = 100. if self.fixed_scale else self.scale.exp()
            p = (scale * x[idx] @ weights.T).softmax(-1)
            h = -(p.clamp_min(1e-12) * p.clamp_min(1e-12).log()).sum(-1)
            r = self.scores(x[idx], p) if self.weighted else torch.ones_like(h)
            loss = (r * h).sum() / r.sum().clamp_min(1e-6)
            optimizer.zero_grad()
            loss.backward()
            if self.variant != 'legacy_bpt5':
                torch.nn.utils.clip_grad_norm_([delta], 1.)
            optimizer.step()
        with torch.no_grad():
            scale = 100. if self.fixed_scale else self.scale.exp()
            logits = scale * x @ F.normalize(self.w + delta, dim=-1).T
            if self.eta:
                p = logits.softmax(-1)
                pred, r = p.argmax(-1), self.scores(x, p)
                threshold = torch.quantile(r, .1) if len(r) > 1 else r.min()
                for c in range(len(self.w)):
                    mask = (pred == c) & (r >= threshold)
                    if mask.any():
                        mean = (r[mask, None] * x[mask]).sum(0) / (r[mask].sum() + 1e-6)
                        self.mu[c] = F.normalize(.7 * self.mu[c] + .3 * mean, dim=0)
            return logits


@torch.no_grad()
def choose_fusion(source, w):
    """Only source domains/labels are passed; target cannot enter validation."""
    candidates = [0., .25, .5, .75, 1.]
    scores = {a: [] for a in candidates}
    for held in source:
        train = [source[d] for d in source if d != held]
        x, y = torch.cat([v[0] for v in train]), torch.cat([v[1] for v in train])
        mu = prototypes(x, y, w)
        vx, vy = source[held]
        for a in candidates:
            logits = vx @ F.normalize((1-a)*w+a*mu,dim=-1).T
            scores[a].append(float((logits.argmax(-1) == vy).float().mean()))
    means = {a: float(np.mean(v)) for a, v in scores.items()}
    selected = max(candidates, key=lambda a: (means[a], -a))
    return selected, means


def mechanism(x, y, w, mu, path):
    from scipy.stats import rankdata
    with torch.no_grad():
        p = (100. * x @ w.T).softmax(-1)
        pred = p.argmax(-1)
        conf = (1 + (p.clamp_min(1e-12) * p.clamp_min(1e-12).log()).sum(-1) / math.log(len(w))).clamp_min(0)
        sim = F.cosine_similarity(x, mu[pred], dim=-1).clamp_min(0)
    correct = (pred == y).cpu().numpy().astype(np.int8)
    values = {'confidence': conf.cpu().numpy(), 'prototype': sim.cpu().numpy(),
              'product': (conf * sim).cpu().numpy()}
    records = {}
    for name, scores in values.items():
        # Stable indices provide deterministic, label-independent tie breaking.
        idx = np.argsort(-scores, kind='stable')
        cumulative = np.cumsum(correct[idx]) / np.arange(1, len(correct)+1)
        bins = []
        for group in np.array_split(idx[::-1], 10):
            k, n = int(correct[group].sum()), len(group)
            ph = k / n
            den = 1+1.96**2/n
            middle = (ph + 1.96**2/(2*n))/den
            half = 1.96*math.sqrt(ph*(1-ph)/n + 1.96**2/(4*n*n))/den
            bins.append({'n': n, 'mean_score': float(scores[group].mean()),
                         'accuracy': ph, 'wilson_low': middle-half, 'wilson_high': middle+half})
        positive=int(correct.sum()); negative=len(correct)-positive
        auc=float((rankdata(scores)[correct==1].sum()-positive*(positive+1)/2)/(positive*negative)) if positive and negative else None
        records[name] = {'correctness_auroc': auc,
                         'aurc': float((1-cumulative).mean()), 'bins': bins,
                         'coverage': [{'coverage': c, 'accuracy': float(cumulative[max(1,int(c*len(idx)))-1])}
                                      for c in [.1,.2,.3,.4,.5,.6,.7,.8,.9,1.]]}
    save_json(path.with_suffix('.json'), records)
    np.savez_compressed(path.with_suffix('.npz'), labels=y.cpu().numpy(), predictions=pred.cpu().numpy(), **values)


def ensure_features(args, spec, bb_name, model):
    from domainbed_dataset import DomainFolderDataset
    from torch.utils.data import DataLoader
    directory = args.out / 'features' / spec.name / bb_name
    directory.mkdir(parents=True, exist_ok=True)
    cache = {}
    for domain in spec.domains:
        ds = DomainFolderDataset(args.data_root, spec.folder, domain, spec.classes, model.preprocess)
        manifest = [{'path': str(Path(p).relative_to(args.data_root)), 'label': int(y), 'bytes': Path(p).stat().st_size} for p,y in ds.samples]
        fingerprint = hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
        dest = directory / (domain + '.pt')
        if dest.exists():
            saved = torch.load(dest, map_location='cpu', weights_only=True)
            assert saved['fingerprint'] == fingerprint, 'Dataset changed; refusing stale cache'
            f, y = saved['features'], saved['labels']
        else:
            loader = DataLoader(ds,batch_size=args.encode_batch,num_workers=4,shuffle=False,pin_memory=True)
            fs, ys = [], []
            begin = time.perf_counter()
            with torch.inference_mode():
                for images, labels in loader:
                    fs.append(model.encode_image(images).float().cpu())
                    ys.append(labels)
            f,y=torch.cat(fs),torch.cat(ys)
            torch.save({'features':f,'labels':y,'fingerprint':fingerprint},dest)
            save_json(directory/(domain+'.manifest.json'),{'dataset_fingerprint':fingerprint,'samples':manifest,
                       'feature_sha256':digest(dest),'extract_seconds':time.perf_counter()-begin,
                       'preprocess':str(model.preprocess),'torch':torch.__version__,'backbone':bb_name})
        assert len(f)==len(ds) and f.isfinite().all()
        cache[domain]=(f.cuda(),y.cuda())
        print('FEATURE_READY',spec.name,bb_name,domain,len(y),flush=True)
    return cache


def run_setting(args,dataset,bb_name):
    from clip_backbone import load_backbone,build_zeroshot_text_weights
    from datasets import get_dataset_spec
    spec=get_dataset_spec(dataset)
    if bb_name=='ViT-B-16-OpenAI-QuickGELU':
        import open_clip
        from clip_backbone import Backbone
        raw,_,preprocess=open_clip.create_model_and_transforms('ViT-B-16',pretrained='openai',force_quick_gelu=True)
        assert 'QuickGELU' in type(raw.visual.transformer.resblocks[0].mlp.gelu).__name__
        bb=Backbone(raw.cuda().eval(),preprocess,open_clip.get_tokenizer('ViT-B-16'),512,'cuda')
    else:
        bb=load_backbone(bb_name,'cuda')
    with torch.inference_mode():
        w=build_zeroshot_text_weights(bb,spec.classes).float().detach().clone()
    # Re-create outside inference mode to permit autograd through residual logits.
    w=w.clone()
    cache=ensure_features(args,spec,bb_name,bb)
    model_param_count=sum(p.numel() for p in bb.model.parameters())
    del bb
    torch.cuda.empty_cache()
    variants=['legacy_bpt5','matched_entropy','confidence_weighted','pr_ema','pr_frozen','source_fusion_tta']
    if dataset=='PACS':
        variants+=['budget_bpt8','pr_frozen_reset_scale','prototype_weighted']
    if args.smoke:
        variants=['matched_entropy','confidence_weighted','pr_ema','pr_frozen']
    seeds=list(range(100,120 if dataset=='PACS' else 110))
    if args.smoke:
        seeds=[100]
    base=args.out/'runs'/dataset/bb_name
    base.mkdir(parents=True,exist_ok=True)
    torch.save(w.cpu(),args.out/'features'/dataset/bb_name/'text_weights.pt')
    for domain in (['sketch'] if args.smoke else spec.domains):
        x,y=cache[domain]
        source={d:cache[d] for d in spec.domains if d!=domain}
        sx=torch.cat([v[0] for v in source.values()]); sy=torch.cat([v[1] for v in source.values()])
        mu=prototypes(sx,sy,w)
        lam,validation=choose_fusion(source,w)
        static={}
        with torch.no_grad():
            for name, logits in [('zeroshot',x@w.T),('source_prototype',x@mu.T),
                                 ('source_fusion',x@F.normalize((1-lam)*w+lam*mu,dim=-1).T)]:
                static[name]={'correct':int((logits.argmax(-1)==y).sum()),'n':len(y),
                              'accuracy':float((logits.argmax(-1)==y).float().mean()*100)}
        save_json(base/(domain+'_source_controls.json'),{'static':static,'fusion_lambda':lam,
                  'source_validation':validation,'target':domain,'source_domains':list(source),
                  'source_n':len(sy),'encoder_parameters':model_param_count})
        mechanism(x,y,w,mu,base/(domain+'_reliability'))
        for seed in seeds:
            order=torch.randperm(len(y),generator=torch.Generator().manual_seed(seed))
            order_hash=hashlib.sha256(order.numpy().tobytes()).hexdigest()
            order=order.cuda()
            for variant in variants:
                dest=base/f'{domain}__{variant}__{seed}.json'
                if dest.exists():
                    continue
                torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
                use_w=F.normalize((1-lam)*w+lam*mu,dim=-1) if variant=='source_fusion_tta' else w
                model=ResidualAdapter(use_w,mu,variant)
                predictions=torch.empty_like(y)
                torch.cuda.reset_peak_memory_stats()
                torch.cuda.synchronize();t0=time.perf_counter()
                batch_records=[]
                for start in range(0,len(order),64):
                    indices=order[start:start+64]
                    logits=model.predict(x[indices])
                    pred=logits.argmax(-1)
                    predictions[indices]=pred
                    batch_records.append({'start':start,'n':len(indices),
                                          'correct':int((pred==y[indices]).sum()),
                                          'scale':float(model.scale.detach())})
                torch.cuda.synchronize();duration=time.perf_counter()-t0
                correct=int((predictions==y).sum())
                np.savez_compressed(dest.with_suffix('.npz'),prediction=predictions.cpu().numpy(),
                                    labels=y.cpu().numpy(),order=order.cpu().numpy())
                save_json(dest,{'dataset':dataset,'backbone':bb_name,'domain':domain,'variant':variant,
                               'seed':seed,'n':len(y),'correct':correct,'accuracy':correct/len(y)*100,
                               'order_sha256':order_hash,'adaptation_seconds':duration,
                               'peak_allocated_bytes':torch.cuda.max_memory_allocated(),
                               'timing_scope':'cached-feature adaptation including scoring; not end-to-end latency',
                               'batches':batch_records})
                print('RUN',dataset,bb_name,domain,variant,seed,round(correct/len(y)*100,4),round(duration,2),flush=True)
    # A fully resumed setting may skip every variant, so no temporary adapter is created.
    del cache,w,mu,sx,sy
    if 'model' in locals():del model
    torch.cuda.empty_cache()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--legacy-code',required=True)
    parser.add_argument('--data-root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--smoke',action='store_true',help='REAL full-Sketch single-order validation, never synthetic')
    parser.add_argument('--encode-batch',type=int,default=96)
    parser.add_argument('--only',nargs=2,metavar=('DATASET','BACKBONE'))
    args=parser.parse_args()
    sys.path.insert(0,args.legacy_code)
    args.out.mkdir(parents=True,exist_ok=True)
    if not torch.cuda.is_available():
        raise RuntimeError('This revision is GPU-only by user instruction')
    torch.set_num_threads(4)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.benchmark=False
    save_json(args.out/'environment.json',{'gpu':torch.cuda.get_device_name(),
              'torch':torch.__version__,'python':sys.version,'platform':platform.platform(),
              'script_sha256':digest(__file__),'argv':sys.argv,'started_unix':time.time(),
              'protocol_sha256':digest(Path(__file__).with_name('PROTOCOL.md'))})
    settings=[('PACS','ViT-B-16'),('OfficeHome','ViT-B-16'),('TerraIncognita','ViT-B-16'),
              ('PACS','ViT-B-16-OpenAI-QuickGELU'),('PACS','ViT-L-14'),('OfficeHome','ViT-L-14'),('TerraIncognita','ViT-L-14')]
    if args.only:
        settings=[tuple(args.only)]
    if args.smoke:
        settings=settings[:1]
    failures=[]
    for ds,bb in settings:
        try:
            print('SETTING_START',ds,bb,flush=True)
            run_setting(args,ds,bb)
            print('SETTING_DONE',ds,bb,flush=True)
        except Exception:
            error=traceback.format_exc();print(error,flush=True)
            failures.append({'dataset':ds,'backbone':bb,'traceback':error})
            save_json(args.out/'failures.json',failures)
            torch.cuda.empty_cache()
    save_json(args.out/'completion.json',{'finished_unix':time.time(),'failures':failures,
              'settings':settings,'complete':not failures,'smoke':args.smoke})
    if failures:
        raise SystemExit(1)


if __name__=='__main__':
    main()
