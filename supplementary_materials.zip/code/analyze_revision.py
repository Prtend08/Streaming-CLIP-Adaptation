"""Strict aggregation of completed GPU records. No smoke or legacy CSV inputs."""
import argparse
from collections import defaultdict
import csv
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy import stats

MATRIX=[('PACS','ViT-B-16',20),('OfficeHome','ViT-B-16',10),('TerraIncognita','ViT-B-16',10),
        ('PACS','ViT-B-16-OpenAI-QuickGELU',20),('PACS','ViT-L-14',20),('OfficeHome','ViT-L-14',10),('TerraIncognita','ViT-L-14',10)]
BASE=['legacy_bpt5','matched_entropy','confidence_weighted','pr_ema','pr_frozen','source_fusion_tta']
EXTRA=['budget_bpt8','pr_frozen_reset_scale','prototype_weighted']

def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,allow_nan=False),encoding='utf-8')

def csv_write(path,rows):
    if not rows:return
    fieldnames=[]
    for row in rows:
        for key in row:
            if key not in fieldnames:fieldnames.append(key)
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fieldnames);w.writeheader();w.writerows(rows)

def holm(values):
    values=np.asarray(values);idx=np.argsort(values);out=np.empty(len(values))
    out[idx]=np.minimum(1,np.maximum.accumulate(values[idx]*(len(idx)-np.arange(len(idx)))))
    return out.tolist()

def signed_rank_exact(d):
    """Exact sign enumeration by integer-rank DP; handles tied absolute differences."""
    d=np.round(np.asarray(d,dtype=float),12);d=d[d!=0]
    if not len(d):return {'p':1.,'n_nonzero':0,'statistic':0.}
    ranks=np.rint(2*stats.rankdata(abs(d))).astype(int)
    mass=np.array([1.])
    for r in ranks:
        new=np.zeros(len(mass)+r);new[:len(mass)]+=mass/2;new[r:]+=mass/2;mass=new
    observed=int(ranks[d>0].sum());total=int(ranks.sum())
    p=min(1.,2*min(mass[:observed+1].sum(),mass[observed:].sum()))
    return {'p':float(p),'n_nonzero':len(d),'statistic':min(observed,total-observed)/2}

def paired(a,b):
    a,b=np.asarray(a,dtype=float),np.asarray(b,dtype=float);d=a-b;n=len(d)
    assert n>=5
    mean=float(d.mean());sd=float(d.std(ddof=1));half=float(stats.t.ppf(.975,n-1)*sd/np.sqrt(n))
    if sd==0:p=1. if mean==0 else 0.;dz=None
    else:p=float(stats.ttest_rel(a,b).pvalue);dz=mean/sd
    boot=d[np.random.default_rng(20260901).integers(n,size=(20000,n))].mean(1)
    rank=signed_rank_exact(d)
    return {'n':n,'delta_pp':mean,'delta_sd':sd,'ci_low':mean-half,'ci_high':mean+half,
            'bootstrap_ci_low':float(np.quantile(boot,.025)),'bootstrap_ci_high':float(np.quantile(boot,.975)),
            'p_t':p,'p_signed_rank_exact':rank['p'],'signed_rank_n_nonzero':rank['n_nonzero'],
            'cohen_dz':dz,'positive_orders':int((d>0).sum()),'negative_orders':int((d<0).sum()),
            'zero_orders':int((d==0).sum()),'paired_differences_pp':d.tolist()}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);args=parser.parse_args()
    root=args.root;out=root/'reports';out.mkdir(exist_ok=True)
    rows=[];summaries=[];comparisons=[];domain_tests=[];mechanisms=[];audit={'runs_checked':0,'npz_checked':0,'errors':[],'complete_settings':[],'incomplete_settings':[]}
    aggregates={}
    for ds,bb,nseeds in MATRIX:
        base=root/'core'/'runs'/ds/bb;variants=BASE+(EXTRA if ds=='PACS' else [])
        controls={p.name.replace('_source_controls.json',''):json.loads(p.read_text()) for p in base.glob('*_source_controls.json')}
        domains=sorted(controls);matrix=defaultdict(dict)
        for p in sorted(base.glob('*__*.json')):
            r=json.loads(p.read_text());key=(r['variant'],r['domain']);seed=r['seed']
            z=np.load(p.with_suffix('.npz'));pred,y,order=z['prediction'],z['labels'],z['order']
            assert len(pred)==len(y)==len(order)==r['n'],str(p)
            assert int((pred==y).sum())==r['correct'],str(p)
            assert np.array_equal(np.sort(order),np.arange(len(order))),str(p)
            assert hashlib.sha256(order.astype(np.int64).tobytes()).hexdigest()==r['order_sha256'],str(p)
            assert abs(r['accuracy']-100*r['correct']/r['n'])<1e-8,str(p)
            assert sum(b['correct'] for b in r['batches'])==r['correct'],str(p)
            row={k:r[k] for k in ['dataset','backbone','domain','variant','seed','n','correct','accuracy','adaptation_seconds','peak_allocated_bytes','order_sha256']}
            rows.append(row);matrix[key][seed]=r['accuracy'];audit['runs_checked']+=1;audit['npz_checked']+=1
        expected=set(range(100,100+nseeds))
        complete=len(domains)==4 and all(set(matrix[(v,d)])==expected for v in variants for d in domains)
        audit['complete_settings' if complete else 'incomplete_settings'].append({'dataset':ds,'backbone':bb,'actual_runs':sum(len(v) for v in matrix.values()),'expected_runs':4*nseeds*len(variants)})
        for d in domains:
            p=base/(d+'_reliability.json')
            if p.exists():
                for name,r in json.loads(p.read_text()).items():
                    mechanisms.append({'dataset':ds,'backbone':bb,'domain':d,'score':name,'auroc':r['correctness_auroc'],'aurc':r['aurc'],'accuracy_at_90pct_coverage':r['coverage'][-2]['accuracy']})
        if not complete:continue # Never summarize a selective subset of orders or domains.
        a={v:np.array([np.mean([matrix[(v,d)][s] for d in domains]) for s in sorted(expected)]) for v in variants}
        for v in ['zeroshot','source_prototype','source_fusion']:
            a[v]=np.repeat(np.mean([100*controls[d]['static'][v]['correct']/controls[d]['static'][v]['n'] for d in domains]),nseeds)
        aggregates[(ds,bb)]=a
        for v,values in a.items():
            invariant=v in ['zeroshot','source_prototype','source_fusion']
            summaries.append({'dataset':ds,'backbone':bb,'variant':v,'n_orders':nseeds,'mean_accuracy':float(values.mean()),'sample_sd':0. if invariant else float(values.std(ddof=1)),'order_invariant':invariant})
        contrasts=[('pr_ema','matched_entropy'),('pr_ema','confidence_weighted'),('pr_frozen','matched_entropy'),('pr_frozen','confidence_weighted'),('pr_ema','zeroshot'),('pr_frozen','zeroshot'),('pr_frozen','pr_ema'),('source_fusion_tta','source_fusion'),('pr_ema','legacy_bpt5')]
        if ds=='PACS':contrasts += [('pr_frozen','pr_frozen_reset_scale'),('budget_bpt8','legacy_bpt5'),('matched_entropy','budget_bpt8')]
        for method,reference in contrasts:
            primary=method=='pr_ema' and reference in ('matched_entropy','confidence_weighted')
            comparisons.append({'dataset':ds,'backbone':bb,'method':method,'reference':reference,'primary':primary,**paired(a[method],a[reference])})
            if reference in ['matched_entropy','confidence_weighted'] and method in ['pr_ema','pr_frozen']:
                family=[]
                for d in domains:
                    family.append({'dataset':ds,'backbone':bb,'domain':d,'method':method,'reference':reference,**paired([matrix[(method,d)][s] for s in sorted(expected)],[matrix[(reference,d)][s] for s in sorted(expected)])})
                for row,pt,pw in zip(family,holm([r['p_t'] for r in family]),holm([r['p_signed_rank_exact'] for r in family])):
                    row.update(p_t_holm_four_domains=pt,p_signed_rank_holm_four_domains=pw)
                domain_tests.extend(family)
    primary=[r for r in comparisons if r['primary']]
    # Fixed 14-hypothesis family. Unfinished settings count as p=1 until completed.
    for row,pt,pw in zip(primary,holm([r['p_t'] for r in primary]+[1.]*(14-len(primary))),holm([r['p_signed_rank_exact'] for r in primary]+[1.]*(14-len(primary)))):
        row.update(p_t_holm_14=pt,p_signed_rank_holm_14=pw)
    audit['all_core_complete']=len(audit['complete_settings'])==7
    audit['ci_scope']='Conditional variation across randomized orders of the same fixed dataset; not independent test populations.'
    audit['historical_data_warning']='Defaults were historically developed using these benchmarks. New order runs are not independent dataset-level confirmation.'
    write(out/'audit.json',audit);write(out/'summaries.json',summaries);write(out/'comparisons.json',comparisons);write(out/'domain_tests.json',domain_tests)
    csv_write(out/'runs.csv',rows);csv_write(out/'summary.csv',summaries);csv_write(out/'mechanism.csv',mechanisms)
    write(out/'mechanism.json',mechanisms)
    aggregate_external_application(root,out)
    csv_write(out/'paired_tests.csv',[{k:v for k,v in r.items() if k!='paired_differences_pp'} for r in comparisons] if len(primary)==len(comparisons) else [{**{k:v for k,v in r.items() if k not in ['paired_differences_pp','p_t_holm_14','p_signed_rank_holm_14']},'p_t_holm_14':r.get('p_t_holm_14'),'p_signed_rank_holm_14':r.get('p_signed_rank_holm_14')} for r in comparisons])
    if aggregates:figures(root,out,aggregates,comparisons)
    print(json.dumps(audit,indent=2))

def aggregate_external_application(root,out):
    external=[]
    dpe=root/'external'/'dpe_quickgelu'
    if (dpe/'completion.json').exists() and json.loads((dpe/'completion.json').read_text()).get('complete'):
        for p in dpe.glob('*.json'):
            if p.name in ['completion.json']:continue
            r=json.loads(p.read_text())
            if 'accuracy' in r:external.append({'family':'DPE','domain':r['domain'],'method':r['method'],'seed':r.get('seed'),'accuracy':r['accuracy'],'n':r['n'],'checkpoint':'OpenAI QuickGELU'})
    pa=root/'external'/'promptalign'
    if (pa/'completion.json').exists() and json.loads((pa/'completion.json').read_text()).get('complete'):
        for p in pa.glob('*.json'):
            if p.name in ['completion.json','provenance.json']:continue
            r=json.loads(p.read_text());external.append({'family':'PromptAlign','domain':r['domain'],'method':r['method'],'seed':r['seed'],'accuracy':r['accuracy'],'n':r['n'],'checkpoint':'MaPLe ImageNet seed1'})
    write(out/'external.json',external);csv_write(out/'external.csv',external)
    app=root/'application';application=[]
    if (app/'completion.json').exists() and json.loads((app/'completion.json').read_text()).get('complete'):
        static=json.loads((app/'static.json').read_text())
        for name,r in static.items():application.append({'kind':'accuracy','method':name,'batch_size':None,'mean_accuracy':r['accuracy'],'sample_sd':None,'n_orders':0,'n':r['n']})
        groups=defaultdict(list)
        for p in app.glob('*_b*_s*.json'):
            r=json.loads(p.read_text());groups[(r['variant'],r['batch_size'])].append(r)
        for (method,batch),records in groups.items():
            values=[r['accuracy'] for r in records];seconds=[r['adaptation_seconds'] for r in records];n=records[0]['n']
            assert all(r['n']==n for r in records)
            application.append({'kind':'accuracy','method':method,'batch_size':batch,
                'mean_accuracy':float(np.mean(values)),'sample_sd':float(np.std(values,ddof=1)),
                'n_orders':len(values),'n':n,'cached_adaptation_seconds_mean':float(np.mean(seconds)),
                'cached_adaptation_seconds_sd':float(np.std(seconds,ddof=1)),
                'cached_adaptation_ms_per_image':float(1000*np.mean(seconds)/n)})
        latency=json.loads((app/'end_to_end_latency.json').read_text())
        for key,r in latency.items():application.append({'kind':'efficiency','method':r['variant'],'batch_size':r['batch_size'],'mean_accuracy':None,'sample_sd':None,'n_orders':None,'n':None,**{k:r[k] for k in ['median_batch_ms','p95_batch_ms','throughput_images_s','incremental_peak_bytes','gpu_board_power_w_mean','gpu_board_power_n_samples']}})
    write(out/'application.json',application);csv_write(out/'application.csv',application)

def figures(root,out,aggregates,comparisons):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Serif','font.size':8,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.dpi':300})
    rows=[r for r in comparisons if r['method'] in ['pr_ema','pr_frozen'] and r['reference']=='matched_entropy']
    fig,ax=plt.subplots(figsize=(6.2,2.8))
    for i,r in enumerate(rows):
        color='#007C91' if r['method']=='pr_ema' else '#D47B24'
        ax.errorbar(r['delta_pp'],i,xerr=[[r['delta_pp']-r['ci_low']],[r['ci_high']-r['delta_pp']]],fmt='o',color=color,capsize=2,ms=3)
    ax.set_yticks(range(len(rows)),[f"{r['dataset']} / {r['backbone'].replace('ViT-','')} / {'EMA' if r['method']=='pr_ema' else 'frozen'}" for r in rows])
    ax.axvline(0,color='.5',lw=.6);ax.set_xlabel('Accuracy difference vs matched entropy (percentage points; 95% order CI)');ax.invert_yaxis()
    fig.tight_layout();fig.savefig(out/'paired_effects.png');fig.savefig(out/'paired_effects.pdf');plt.close(fig)
    # Include both a successful-looking domain and the previously adverse benchmark, fixed in advance.
    selected=[('PACS','sketch'),('TerraIncognita','location_38')]
    fig,axes=plt.subplots(1,2,figsize=(6.2,2.25))
    for ax,(ds,domain) in zip(axes,selected):
        base=root/'core'/'runs'/ds/'ViT-B-16';p=base/(domain+'_reliability.json')
        if not p.exists():
            options=sorted(base.glob('*_reliability.json'))
            if not options:ax.set_visible(False);continue
            p=options[0];domain=p.stem.replace('_reliability','')
        for name,color in [('confidence','#666666'),('prototype','#D47B24'),('product','#007C91')]:
            r=json.loads(p.read_text())[name];v=r['coverage'];ax.plot([x['coverage'] for x in v],[100*(1-x['accuracy']) for x in v],'-o',ms=2,lw=1,label=name,color=color)
        ax.set_title(ds+' / '+domain);ax.set_xlabel('Retained coverage');ax.set_ylabel('Pseudo-label error (%)');ax.legend(frameon=False,fontsize=7)
    fig.tight_layout();fig.savefig(out/'reliability_risk.png');fig.savefig(out/'reliability_risk.pdf');plt.close(fig)

if __name__=='__main__':main()
