"""Seven-setting cached-feature evaluation of the source-calibrated safety gate."""
from __future__ import annotations
import argparse, hashlib, json, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from run_revision import ResidualAdapter, prototypes, save_json, digest

SETTINGS=[('TerraIncognita','ViT-B-16')]

def run_setting(root, out, dataset, backbone):
    feature_dir=root/'core/features'/dataset/backbone
    w=torch.load(feature_dir/'text_weights.pt',map_location='cuda',weights_only=True).cuda()
    domains=sorted(p.stem for p in feature_dir.glob('*.pt') if p.name!='text_weights.pt')
    cache={}
    for domain in domains:
        s=torch.load(feature_dir/(domain+'.pt'),map_location='cuda',weights_only=True)
        cache[domain]=(s['features'].cuda(),s['labels'].cuda())
    seeds=range(100,120 if dataset=='PACS' else 110)
    for domain in domains:
        x,y=cache[domain]
        source_domains=[d for d in domains if d!=domain]
        sx=torch.cat([cache[d][0] for d in source_domains]);sy=torch.cat([cache[d][1] for d in source_domains])
        mu=prototypes(sx,sy,w)
        tau,cal=source_threshold_generic(w,cache,source_domains)
        save_json(out/'calibration'/dataset/backbone/(domain+'.json'),cal)
        for seed in seeds:
            dest=out/'runs'/dataset/backbone/(f'{domain}__pgr_gate__{seed}.json')
            if dest.exists():continue
            order=torch.randperm(len(y),generator=torch.Generator().manual_seed(seed)).cuda()
            torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
            model=ResidualAdapter(w,mu,'pr_frozen');predictions=torch.empty_like(y)
            gates=[];scores=[];records=[];begin=time.time()
            for start in range(0,len(order),64):
                idx=order[start:start+64]
                with torch.no_grad():
                    p0=(100.*x[idx]@w.T).softmax(-1)
                    score=float(model.scores(x[idx],p0).median())
                enabled=bool(score>=tau)
                logits=model.predict(x[idx]) if enabled else 100.*x[idx]@w.T
                predictions[idx]=logits.argmax(-1);gates.append(enabled);scores.append(score)
                records.append({'start':start,'n':len(idx),'gate_enabled':enabled,'batch_median_score':score,
                                'threshold':tau,'scale':float(model.scale.detach())})
            correct=int((predictions==y).sum())
            npz=dest.with_suffix('.npz');npz.parent.mkdir(parents=True,exist_ok=True)
            np.savez_compressed(npz,prediction=predictions.cpu().numpy(),labels=y.cpu().numpy(),
                                order=order.cpu().numpy(),gate=np.asarray(gates,dtype=np.int8),
                                batch_score=np.asarray(scores))
            save_json(dest,{'complete':True,'dataset':dataset,'backbone':backbone,'domain':domain,
                'variant':'pgr_gate','seed':seed,'n':len(y),'correct':correct,'accuracy':correct/len(y)*100,
                'threshold':tau,'enabled_batches':int(np.sum(gates)),'enabled_fraction':float(np.mean(gates)),
                'order_sha256':hashlib.sha256(order.cpu().numpy().tobytes()).hexdigest(),
                'prediction_sha256':digest(npz),'elapsed_seconds':time.time()-begin,'batches':records})
            print('GATE_RUN',dataset,backbone,domain,seed,round(correct/len(y)*100,4),
                  int(np.sum(gates)),'/',len(gates),flush=True)

@torch.no_grad()
def source_threshold_generic(w,cache,source_domains,quantile=.25):
    values=[]
    for held in source_domains:
        train=[cache[d] for d in source_domains if d!=held]
        mu=prototypes(torch.cat([v[0] for v in train]),torch.cat([v[1] for v in train]),w)
        x,y=cache[held];p=(100.*x@w.T).softmax(-1)
        score=ResidualAdapter(w,mu,'pr_frozen').scores(x,p)
        values.extend(score[p.argmax(-1).eq(y)].cpu().tolist())
    vals=np.asarray(values,dtype=np.float64);tau=float(np.quantile(vals,quantile))
    return tau,{'quantile':quantile,'n_source_correct':len(vals),'threshold':tau,
                'source_domains':source_domains,'target_labels_used':False}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();assert torch.cuda.is_available();args.out.mkdir(parents=True,exist_ok=True)
    save_json(args.out/'protocol.json',{'settings':SETTINGS,'quantile':.25,'fallback':'zero-shot',
      'target_labels_used_by_gate':False,'orders':'locked: PACS 100-119; OfficeHome/TerraIncognita 100-109',
      'interpretation':'post-revision candidate guardrail, evaluated after the main study; not confirmatory evidence'})
    for setting in SETTINGS:run_setting(args.root,args.out,*setting)
    runs=list((args.out/'runs').rglob('*.json'))
    save_json(args.out/'completion.json',{'complete':len(runs)==40,'run_count':len(runs),'expected':40,'finished_at':time.time()})
    assert len(runs)==40,len(runs)
if __name__=='__main__':main()
